# P17 — Reader Bottleneck Characterization

- pre-reg: METHODOLOGY_NOTE_P17.md (commits 37e3181 + 1a8a08c)
- subset: subset500_v2 (n_full=496, n_kept_primary=495)
  - excluded for short-distractors: 1
  - gold via fallback (`pos_item_ids[0]`): 140 qids
- model: Qwen/Qwen2.5-VL-7B-Instruct
- hardware: NVIDIA RTX 6000 Ada Generation  torch: 2.11.0+cu128  cuDNN SDP: disabled
- wall: 77.7 min  peak VRAM: 19.29 GB
- reader cache: unique=6435 / total_cells=6435 (reuse savings 0.0%)

## Plot

![acc vs k](acc_vs_k.png)

## Primary (full n)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 495 | 64.85% | [60.54, 68.93] | 174 |
| **k3_first** | 3 | first | 0 | 495 | 61.01% | [56.64, 65.21] | 193 |
| **k3_middle** | 3 | middle | 1 | 495 | 62.02% | [57.67, 66.19] | 188 |
| **k3_last** | 3 | last | 2 | 495 | 61.41% | [57.05, 65.60] | 191 |
| **k5_first** | 5 | first | 0 | 495 | 60.61% | [56.24, 64.81] | 195 |
| **k5_middle** | 5 | middle | 2 | 495 | 61.01% | [56.64, 65.21] | 193 |
| **k5_last** | 5 | last | 4 | 495 | 58.59% | [54.20, 62.84] | 205 |
| **k10_first** | 10 | first | 0 | 495 | 56.36% | [51.96, 60.67] | 216 |
| **k10_middle** | 10 | middle | 4 | 495 | 57.37% | [52.98, 61.66] | 211 |
| **k10_last** | 10 | last | 9 | 495 | 52.53% | [48.12, 56.89] | 235 |
| **k20_first** | 20 | first | 0 | 495 | 52.93% | [48.53, 57.29] | 233 |
| **k20_middle** | 20 | middle | 9 | 495 | 50.71% | [46.31, 55.09] | 244 |
| **k20_last** | 20 | last | 19 | 495 | 46.87% | [42.51, 51.27] | 263 |

## Sensitivity (exclude gold-via-fallback rows)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 355 | 70.14% | [65.19, 74.67] | 106 |
| **k3_first** | 3 | first | 0 | 355 | 65.63% | [60.55, 70.38] | 122 |
| **k3_middle** | 3 | middle | 1 | 355 | 66.76% | [61.70, 71.46] | 118 |
| **k3_last** | 3 | last | 2 | 355 | 65.63% | [60.55, 70.38] | 122 |
| **k5_first** | 5 | first | 0 | 355 | 65.92% | [60.84, 70.65] | 121 |
| **k5_middle** | 5 | middle | 2 | 355 | 65.92% | [60.84, 70.65] | 121 |
| **k5_last** | 5 | last | 4 | 355 | 63.10% | [57.96, 67.95] | 131 |
| **k10_first** | 10 | first | 0 | 355 | 60.28% | [55.11, 65.24] | 141 |
| **k10_middle** | 10 | middle | 4 | 355 | 62.25% | [57.11, 67.14] | 134 |
| **k10_last** | 10 | last | 9 | 355 | 57.46% | [52.27, 62.50] | 151 |
| **k20_first** | 20 | first | 0 | 355 | 57.18% | [51.99, 62.23] | 152 |
| **k20_middle** | 20 | middle | 9 | 355 | 55.21% | [50.01, 60.30] | 159 |
| **k20_last** | 20 | last | 19 | 355 | 50.70% | [45.52, 55.87] | 175 |

## Distractor / error analysis (primary)

Per-cell breakdown of error categories, as % of errors in that cell.

| cell | k | position | n_err | extraction_failed | distractor_lift | ambiguous_in_context | hallucinated | dlift_rank_median |
|------|---|----------|------:|------------------:|----------------:|---------------------:|-------------:|------------------:|
| k1 | 1 | - | 174 | 55.2% | 0.0% | 0.0% | 44.8% | - |
| k3_first | 3 | first | 193 | 38.3% | 17.6% | 9.8% | 34.2% | 0 |
| k3_middle | 3 | middle | 188 | 36.7% | 17.0% | 8.5% | 37.8% | 0 |
| k3_last | 3 | last | 191 | 35.6% | 19.4% | 7.9% | 37.2% | 1 |
| k5_first | 5 | first | 195 | 32.8% | 21.5% | 12.8% | 32.8% | 1 |
| k5_middle | 5 | middle | 193 | 30.1% | 25.4% | 10.9% | 33.7% | 1 |
| k5_last | 5 | last | 205 | 26.8% | 28.8% | 11.2% | 33.2% | 1 |
| k10_first | 10 | first | 216 | 24.1% | 32.9% | 15.7% | 27.3% | 3 |
| k10_middle | 10 | middle | 211 | 21.8% | 34.1% | 13.3% | 30.8% | 3 |
| k10_last | 10 | last | 235 | 18.3% | 39.1% | 13.6% | 28.9% | 3 |
| k20_first | 20 | first | 233 | 16.3% | 42.9% | 15.5% | 25.3% | 5 |
| k20_middle | 20 | middle | 244 | 17.2% | 42.2% | 14.8% | 25.8% | 5 |
| k20_last | 20 | last | 263 | 14.4% | 45.2% | 16.0% | 24.3% | 5 |

`dlift_rank_median` = median PreFLMR rank (within top-50) of the chosen distractor passage on `distractor_lift` errors. Lower = more semantically similar to the query.

## Notes

- Greedy 7B reader, original question text only, GOLD_IN.
- Distractor-bucket categorization uses case-insensitive ASCII-folded substring match (heuristic; under-counts paraphrases).
- Sensitivity table re-evaluates on the subset where the chosen gold actually appears in PreFLMR top-50 (drops fallback rows). `gold_via_fallback` column in predictions_*.jsonl supports any further re-slicing.
