# P17 — Reader Bottleneck Characterization

- pre-reg: METHODOLOGY_NOTE_P17.md (commits 37e3181 + 1a8a08c)
- subset: subset500_v2 (n_full=496, n_kept_primary=495)
  - excluded for short-distractors: 1
  - gold via fallback (`pos_item_ids[0]`): 140 qids
- model: Qwen/Qwen2.5-VL-7B-Instruct
- hardware: NVIDIA RTX 6000 Ada Generation  torch: 2.11.0+cu128  cuDNN SDP: disabled
- wall: 74.7 min  peak VRAM: 19.29 GB
- reader cache: unique=6435 / total_cells=6435 (reuse savings 0.0%)

## Plot

![acc vs k](acc_vs_k.png)

## Primary (full n)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 495 | 65.86% | [61.57, 69.90] | 169 |
| **k3_first** | 3 | first | 0 | 495 | 57.78% | [53.38, 62.05] | 209 |
| **k3_middle** | 3 | middle | 1 | 495 | 61.41% | [57.05, 65.60] | 191 |
| **k3_last** | 3 | last | 2 | 495 | 64.04% | [59.72, 68.14] | 178 |
| **k5_first** | 5 | first | 0 | 495 | 57.78% | [53.38, 62.05] | 209 |
| **k5_middle** | 5 | middle | 2 | 495 | 58.18% | [53.79, 62.45] | 207 |
| **k5_last** | 5 | last | 4 | 495 | 62.22% | [57.87, 66.38] | 187 |
| **k10_first** | 10 | first | 0 | 495 | 55.15% | [50.75, 59.48] | 222 |
| **k10_middle** | 10 | middle | 4 | 495 | 54.55% | [50.14, 58.88] | 225 |
| **k10_last** | 10 | last | 9 | 495 | 57.17% | [52.77, 61.46] | 212 |
| **k20_first** | 20 | first | 0 | 495 | 53.13% | [48.73, 57.49] | 232 |
| **k20_middle** | 20 | middle | 9 | 495 | 52.32% | [47.92, 56.69] | 236 |
| **k20_last** | 20 | last | 19 | 495 | 52.73% | [48.32, 57.09] | 234 |

## Sensitivity (exclude gold-via-fallback rows)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 355 | 71.55% | [66.64, 75.99] | 101 |
| **k3_first** | 3 | first | 0 | 355 | 62.25% | [57.11, 67.14] | 134 |
| **k3_middle** | 3 | middle | 1 | 355 | 67.61% | [62.57, 72.26] | 115 |
| **k3_last** | 3 | last | 2 | 355 | 69.86% | [64.89, 74.40] | 107 |
| **k5_first** | 5 | first | 0 | 355 | 61.97% | [56.82, 66.87] | 135 |
| **k5_middle** | 5 | middle | 2 | 355 | 63.66% | [58.54, 68.49] | 129 |
| **k5_last** | 5 | last | 4 | 355 | 68.45% | [63.44, 73.07] | 112 |
| **k10_first** | 10 | first | 0 | 355 | 60.28% | [55.11, 65.24] | 141 |
| **k10_middle** | 10 | middle | 4 | 355 | 61.13% | [55.96, 66.05] | 138 |
| **k10_last** | 10 | last | 9 | 355 | 63.10% | [57.96, 67.95] | 131 |
| **k20_first** | 20 | first | 0 | 355 | 57.75% | [52.55, 62.78] | 150 |
| **k20_middle** | 20 | middle | 9 | 355 | 58.03% | [52.84, 63.05] | 149 |
| **k20_last** | 20 | last | 19 | 355 | 58.87% | [53.69, 63.87] | 146 |

## Distractor / error analysis (primary)

Per-cell breakdown of error categories, as % of errors in that cell.

| cell | k | position | n_err | extraction_failed | distractor_lift | ambiguous_in_context | hallucinated | dlift_rank_median |
|------|---|----------|------:|------------------:|----------------:|---------------------:|-------------:|------------------:|
| k1 | 1 | - | 169 | 53.3% | 0.0% | 0.0% | 46.7% | - |
| k3_first | 3 | first | 209 | 30.6% | 25.8% | 8.1% | 35.4% | 1 |
| k3_middle | 3 | middle | 191 | 33.0% | 22.0% | 8.9% | 36.1% | 1 |
| k3_last | 3 | last | 178 | 37.6% | 16.9% | 9.0% | 36.5% | 0 |
| k5_first | 5 | first | 209 | 25.8% | 31.6% | 10.0% | 32.5% | 1 |
| k5_middle | 5 | middle | 207 | 30.0% | 27.5% | 9.7% | 32.9% | 1 |
| k5_last | 5 | last | 187 | 30.5% | 24.6% | 9.6% | 35.3% | 1 |
| k10_first | 10 | first | 222 | 19.4% | 37.8% | 14.0% | 28.8% | 2 |
| k10_middle | 10 | middle | 225 | 21.3% | 36.9% | 11.1% | 30.7% | 2 |
| k10_last | 10 | last | 212 | 24.5% | 32.1% | 12.7% | 30.7% | 2 |
| k20_first | 20 | first | 232 | 16.4% | 48.7% | 12.1% | 22.8% | 5 |
| k20_middle | 20 | middle | 236 | 18.6% | 43.2% | 12.7% | 25.4% | 5 |
| k20_last | 20 | last | 234 | 17.9% | 41.0% | 15.4% | 25.6% | 4 |

`dlift_rank_median` = median PreFLMR rank (within top-50) of the chosen distractor passage on `distractor_lift` errors. Lower = more semantically similar to the query.

## Notes

- Greedy 7B reader, original question text only, GOLD_IN.
- Distractor-bucket categorization uses case-insensitive ASCII-folded substring match (heuristic; under-counts paraphrases).
- Sensitivity table re-evaluates on the subset where the chosen gold actually appears in PreFLMR top-50 (drops fallback rows). `gold_via_fallback` column in predictions_*.jsonl supports any further re-slicing.
