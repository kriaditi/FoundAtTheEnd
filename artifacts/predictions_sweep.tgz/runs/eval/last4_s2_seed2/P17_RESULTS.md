# P17 — Reader Bottleneck Characterization

- pre-reg: METHODOLOGY_NOTE_P17.md (commits 37e3181 + 1a8a08c)
- subset: subset500_v2 (n_full=496, n_kept_primary=495)
  - excluded for short-distractors: 1
  - gold via fallback (`pos_item_ids[0]`): 140 qids
- model: Qwen/Qwen2.5-VL-7B-Instruct
- hardware: NVIDIA RTX 6000 Ada Generation  torch: 2.11.0+cu128  cuDNN SDP: disabled
- wall: 78.4 min  peak VRAM: 19.29 GB
- reader cache: unique=6435 / total_cells=6435 (reuse savings 0.0%)

## Plot

![acc vs k](acc_vs_k.png)

## Primary (full n)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 495 | 61.82% | [57.46, 65.99] | 189 |
| **k3_first** | 3 | first | 0 | 495 | 59.60% | [55.22, 63.83] | 200 |
| **k3_middle** | 3 | middle | 1 | 495 | 60.20% | [55.83, 64.42] | 197 |
| **k3_last** | 3 | last | 2 | 495 | 59.60% | [55.22, 63.83] | 200 |
| **k5_first** | 5 | first | 0 | 495 | 57.98% | [53.59, 62.25] | 208 |
| **k5_middle** | 5 | middle | 2 | 495 | 60.40% | [56.03, 64.62] | 196 |
| **k5_last** | 5 | last | 4 | 495 | 57.58% | [53.18, 61.85] | 210 |
| **k10_first** | 10 | first | 0 | 495 | 53.54% | [49.13, 57.89] | 230 |
| **k10_middle** | 10 | middle | 4 | 495 | 54.34% | [49.94, 58.68] | 226 |
| **k10_last** | 10 | last | 9 | 495 | 50.71% | [46.31, 55.09] | 244 |
| **k20_first** | 20 | first | 0 | 495 | 49.09% | [44.71, 53.48] | 252 |
| **k20_middle** | 20 | middle | 9 | 495 | 49.29% | [44.91, 53.69] | 251 |
| **k20_last** | 20 | last | 19 | 495 | 46.46% | [42.11, 50.87] | 265 |

## Sensitivity (exclude gold-via-fallback rows)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 355 | 64.79% | [59.69, 69.57] | 125 |
| **k3_first** | 3 | first | 0 | 355 | 63.10% | [57.96, 67.95] | 131 |
| **k3_middle** | 3 | middle | 1 | 355 | 64.51% | [59.40, 69.31] | 126 |
| **k3_last** | 3 | last | 2 | 355 | 63.38% | [58.25, 68.22] | 130 |
| **k5_first** | 5 | first | 0 | 355 | 61.41% | [56.25, 66.32] | 137 |
| **k5_middle** | 5 | middle | 2 | 355 | 64.51% | [59.40, 69.31] | 126 |
| **k5_last** | 5 | last | 4 | 355 | 61.41% | [56.25, 66.32] | 137 |
| **k10_first** | 10 | first | 0 | 355 | 58.31% | [53.12, 63.32] | 148 |
| **k10_middle** | 10 | middle | 4 | 355 | 58.87% | [53.69, 63.87] | 146 |
| **k10_last** | 10 | last | 9 | 355 | 55.49% | [50.29, 60.58] | 158 |
| **k20_first** | 20 | first | 0 | 355 | 54.37% | [49.17, 59.47] | 162 |
| **k20_middle** | 20 | middle | 9 | 355 | 52.68% | [47.48, 57.81] | 168 |
| **k20_last** | 20 | last | 19 | 355 | 51.27% | [46.08, 56.43] | 173 |

## Distractor / error analysis (primary)

Per-cell breakdown of error categories, as % of errors in that cell.

| cell | k | position | n_err | extraction_failed | distractor_lift | ambiguous_in_context | hallucinated | dlift_rank_median |
|------|---|----------|------:|------------------:|----------------:|---------------------:|-------------:|------------------:|
| k1 | 1 | - | 189 | 54.5% | 0.0% | 0.0% | 45.5% | - |
| k3_first | 3 | first | 200 | 35.0% | 18.0% | 11.0% | 36.0% | 0 |
| k3_middle | 3 | middle | 197 | 35.5% | 16.2% | 11.2% | 37.1% | 0 |
| k3_last | 3 | last | 200 | 34.0% | 20.0% | 12.0% | 34.0% | 0 |
| k5_first | 5 | first | 208 | 29.8% | 24.5% | 11.5% | 34.1% | 1 |
| k5_middle | 5 | middle | 196 | 32.1% | 25.0% | 11.7% | 31.1% | 1 |
| k5_last | 5 | last | 210 | 28.6% | 28.1% | 11.9% | 31.4% | 1 |
| k10_first | 10 | first | 230 | 24.3% | 35.2% | 14.3% | 26.1% | 2 |
| k10_middle | 10 | middle | 226 | 24.3% | 33.2% | 15.0% | 27.4% | 2 |
| k10_last | 10 | last | 244 | 20.9% | 36.5% | 14.8% | 27.9% | 2 |
| k20_first | 20 | first | 252 | 17.5% | 41.7% | 15.9% | 25.0% | 4 |
| k20_middle | 20 | middle | 251 | 17.5% | 38.6% | 17.1% | 26.7% | 4 |
| k20_last | 20 | last | 265 | 16.6% | 42.3% | 16.2% | 24.9% | 4 |

`dlift_rank_median` = median PreFLMR rank (within top-50) of the chosen distractor passage on `distractor_lift` errors. Lower = more semantically similar to the query.

## Notes

- Greedy 7B reader, original question text only, GOLD_IN.
- Distractor-bucket categorization uses case-insensitive ASCII-folded substring match (heuristic; under-counts paraphrases).
- Sensitivity table re-evaluates on the subset where the chosen gold actually appears in PreFLMR top-50 (drops fallback rows). `gold_via_fallback` column in predictions_*.jsonl supports any further re-slicing.
