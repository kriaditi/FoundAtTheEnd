# P17 — Reader Bottleneck Characterization

- pre-reg: METHODOLOGY_NOTE_P17.md (commits 37e3181 + 1a8a08c)
- subset: subset500_v2 (n_full=496, n_kept_primary=495)
  - excluded for short-distractors: 1
  - gold via fallback (`pos_item_ids[0]`): 140 qids
- model: Qwen/Qwen2.5-VL-7B-Instruct
- hardware: NVIDIA RTX 6000 Ada Generation  torch: 2.11.0+cu128  cuDNN SDP: disabled
- wall: 76.9 min  peak VRAM: 19.29 GB
- reader cache: unique=6435 / total_cells=6435 (reuse savings 0.0%)

## Plot

![acc vs k](acc_vs_k.png)

## Primary (full n)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 495 | 66.26% | [61.99, 70.29] | 167 |
| **k3_first** | 3 | first | 0 | 495 | 59.39% | [55.01, 63.63] | 201 |
| **k3_middle** | 3 | middle | 1 | 495 | 59.39% | [55.01, 63.63] | 201 |
| **k3_last** | 3 | last | 2 | 495 | 61.62% | [57.26, 65.80] | 190 |
| **k5_first** | 5 | first | 0 | 495 | 58.18% | [53.79, 62.45] | 207 |
| **k5_middle** | 5 | middle | 2 | 495 | 58.38% | [53.99, 62.65] | 206 |
| **k5_last** | 5 | last | 4 | 495 | 59.80% | [55.42, 64.03] | 199 |
| **k10_first** | 10 | first | 0 | 495 | 54.14% | [49.74, 58.48] | 227 |
| **k10_middle** | 10 | middle | 4 | 495 | 53.54% | [49.13, 57.89] | 230 |
| **k10_last** | 10 | last | 9 | 495 | 55.76% | [51.35, 60.07] | 219 |
| **k20_first** | 20 | first | 0 | 495 | 50.71% | [46.31, 55.09] | 244 |
| **k20_middle** | 20 | middle | 9 | 495 | 49.90% | [45.51, 54.29] | 248 |
| **k20_last** | 20 | last | 19 | 495 | 53.74% | [49.33, 58.08] | 229 |

## Sensitivity (exclude gold-via-fallback rows)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 355 | 72.39% | [67.52, 76.79] | 98 |
| **k3_first** | 3 | first | 0 | 355 | 63.94% | [58.82, 68.76] | 128 |
| **k3_middle** | 3 | middle | 1 | 355 | 65.07% | [59.97, 69.84] | 124 |
| **k3_last** | 3 | last | 2 | 355 | 66.48% | [61.41, 71.19] | 119 |
| **k5_first** | 5 | first | 0 | 355 | 63.66% | [58.54, 68.49] | 129 |
| **k5_middle** | 5 | middle | 2 | 355 | 62.82% | [57.68, 67.68] | 132 |
| **k5_last** | 5 | last | 4 | 355 | 65.07% | [59.97, 69.84] | 124 |
| **k10_first** | 10 | first | 0 | 355 | 59.44% | [54.25, 64.42] | 144 |
| **k10_middle** | 10 | middle | 4 | 355 | 58.03% | [52.84, 63.05] | 149 |
| **k10_last** | 10 | last | 9 | 355 | 59.72% | [54.54, 64.69] | 143 |
| **k20_first** | 20 | first | 0 | 355 | 56.06% | [50.86, 61.13] | 156 |
| **k20_middle** | 20 | middle | 9 | 355 | 54.65% | [49.45, 59.75] | 161 |
| **k20_last** | 20 | last | 19 | 355 | 58.31% | [53.12, 63.32] | 148 |

## Distractor / error analysis (primary)

Per-cell breakdown of error categories, as % of errors in that cell.

| cell | k | position | n_err | extraction_failed | distractor_lift | ambiguous_in_context | hallucinated | dlift_rank_median |
|------|---|----------|------:|------------------:|----------------:|---------------------:|-------------:|------------------:|
| k1 | 1 | - | 167 | 55.1% | 0.0% | 0.0% | 44.9% | - |
| k3_first | 3 | first | 201 | 31.8% | 21.9% | 10.9% | 35.3% | 0 |
| k3_middle | 3 | middle | 201 | 31.3% | 21.4% | 10.0% | 37.3% | 0 |
| k3_last | 3 | last | 190 | 38.4% | 21.1% | 9.5% | 31.1% | 1 |
| k5_first | 5 | first | 207 | 27.1% | 26.1% | 12.6% | 34.3% | 1 |
| k5_middle | 5 | middle | 206 | 28.2% | 26.7% | 12.1% | 33.0% | 1 |
| k5_last | 5 | last | 199 | 33.2% | 24.6% | 11.6% | 30.7% | 1 |
| k10_first | 10 | first | 227 | 18.5% | 37.9% | 15.0% | 28.6% | 4 |
| k10_middle | 10 | middle | 230 | 20.4% | 36.1% | 13.5% | 30.0% | 3 |
| k10_last | 10 | last | 219 | 23.7% | 31.5% | 16.9% | 27.9% | 3 |
| k20_first | 20 | first | 244 | 13.1% | 45.9% | 16.4% | 24.6% | 4 |
| k20_middle | 20 | middle | 248 | 15.7% | 42.3% | 16.9% | 25.0% | 5 |
| k20_last | 20 | last | 229 | 19.2% | 36.2% | 20.5% | 24.0% | 4 |

`dlift_rank_median` = median PreFLMR rank (within top-50) of the chosen distractor passage on `distractor_lift` errors. Lower = more semantically similar to the query.

## Notes

- Greedy 7B reader, original question text only, GOLD_IN.
- Distractor-bucket categorization uses case-insensitive ASCII-folded substring match (heuristic; under-counts paraphrases).
- Sensitivity table re-evaluates on the subset where the chosen gold actually appears in PreFLMR top-50 (drops fallback rows). `gold_via_fallback` column in predictions_*.jsonl supports any further re-slicing.
