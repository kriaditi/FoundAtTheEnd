# P17 — Reader Bottleneck Characterization

- pre-reg: METHODOLOGY_NOTE_P17.md (commits 37e3181 + 1a8a08c)
- subset: subset500_v2 (n_full=496, n_kept_primary=495)
  - excluded for short-distractors: 1
  - gold via fallback (`pos_item_ids[0]`): 140 qids
- model: Qwen/Qwen2.5-VL-7B-Instruct
- hardware: NVIDIA RTX 6000 Ada Generation  torch: 2.11.0+cu128  cuDNN SDP: disabled
- wall: 77.6 min  peak VRAM: 19.29 GB
- reader cache: unique=6435 / total_cells=6435 (reuse savings 0.0%)

## Plot

![acc vs k](acc_vs_k.png)

## Primary (full n)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 495 | 63.84% | [59.51, 67.95] | 179 |
| **k3_first** | 3 | first | 0 | 495 | 59.19% | [54.81, 63.43] | 202 |
| **k3_middle** | 3 | middle | 1 | 495 | 60.40% | [56.03, 64.62] | 196 |
| **k3_last** | 3 | last | 2 | 495 | 61.21% | [56.85, 65.40] | 192 |
| **k5_first** | 5 | first | 0 | 495 | 58.18% | [53.79, 62.45] | 207 |
| **k5_middle** | 5 | middle | 2 | 495 | 60.81% | [56.44, 65.01] | 194 |
| **k5_last** | 5 | last | 4 | 495 | 58.59% | [54.20, 62.84] | 205 |
| **k10_first** | 10 | first | 0 | 495 | 55.15% | [50.75, 59.48] | 222 |
| **k10_middle** | 10 | middle | 4 | 495 | 56.57% | [52.17, 60.87] | 215 |
| **k10_last** | 10 | last | 9 | 495 | 51.92% | [47.52, 56.29] | 238 |
| **k20_first** | 20 | first | 0 | 495 | 51.52% | [47.12, 55.89] | 240 |
| **k20_middle** | 20 | middle | 9 | 495 | 50.51% | [46.11, 54.89] | 245 |
| **k20_last** | 20 | last | 19 | 495 | 46.67% | [42.31, 51.07] | 264 |

## Sensitivity (exclude gold-via-fallback rows)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 355 | 67.89% | [62.86, 72.53] | 114 |
| **k3_first** | 3 | first | 0 | 355 | 63.38% | [58.25, 68.22] | 130 |
| **k3_middle** | 3 | middle | 1 | 355 | 64.79% | [59.69, 69.57] | 125 |
| **k3_last** | 3 | last | 2 | 355 | 64.51% | [59.40, 69.31] | 126 |
| **k5_first** | 5 | first | 0 | 355 | 62.82% | [57.68, 67.68] | 132 |
| **k5_middle** | 5 | middle | 2 | 355 | 64.79% | [59.69, 69.57] | 125 |
| **k5_last** | 5 | last | 4 | 355 | 62.82% | [57.68, 67.68] | 132 |
| **k10_first** | 10 | first | 0 | 355 | 59.72% | [54.54, 64.69] | 143 |
| **k10_middle** | 10 | middle | 4 | 355 | 60.85% | [55.68, 65.78] | 139 |
| **k10_last** | 10 | last | 9 | 355 | 54.65% | [49.45, 59.75] | 161 |
| **k20_first** | 20 | first | 0 | 355 | 56.34% | [51.14, 61.40] | 155 |
| **k20_middle** | 20 | middle | 9 | 355 | 53.52% | [48.32, 58.64] | 165 |
| **k20_last** | 20 | last | 19 | 355 | 50.42% | [45.24, 55.59] | 176 |

## Distractor / error analysis (primary)

Per-cell breakdown of error categories, as % of errors in that cell.

| cell | k | position | n_err | extraction_failed | distractor_lift | ambiguous_in_context | hallucinated | dlift_rank_median |
|------|---|----------|------:|------------------:|----------------:|---------------------:|-------------:|------------------:|
| k1 | 1 | - | 179 | 50.3% | 0.0% | 0.0% | 49.7% | - |
| k3_first | 3 | first | 202 | 34.7% | 18.3% | 9.9% | 37.1% | 1 |
| k3_middle | 3 | middle | 196 | 37.8% | 16.8% | 10.2% | 35.2% | 0 |
| k3_last | 3 | last | 192 | 33.9% | 19.8% | 9.4% | 37.0% | 1 |
| k5_first | 5 | first | 207 | 29.5% | 28.5% | 10.6% | 31.4% | 1 |
| k5_middle | 5 | middle | 194 | 30.4% | 28.4% | 11.3% | 29.9% | 1 |
| k5_last | 5 | last | 205 | 26.3% | 34.6% | 9.3% | 29.8% | 1 |
| k10_first | 10 | first | 222 | 20.7% | 41.0% | 14.0% | 24.3% | 3 |
| k10_middle | 10 | middle | 215 | 18.1% | 37.2% | 15.3% | 29.3% | 3 |
| k10_last | 10 | last | 238 | 18.1% | 42.4% | 13.9% | 25.6% | 3 |
| k20_first | 20 | first | 240 | 16.2% | 42.9% | 16.7% | 24.2% | 3 |
| k20_middle | 20 | middle | 245 | 17.1% | 42.0% | 15.1% | 25.7% | 4 |
| k20_last | 20 | last | 264 | 12.5% | 48.1% | 15.5% | 23.9% | 4 |

`dlift_rank_median` = median PreFLMR rank (within top-50) of the chosen distractor passage on `distractor_lift` errors. Lower = more semantically similar to the query.

## Notes

- Greedy 7B reader, original question text only, GOLD_IN.
- Distractor-bucket categorization uses case-insensitive ASCII-folded substring match (heuristic; under-counts paraphrases).
- Sensitivity table re-evaluates on the subset where the chosen gold actually appears in PreFLMR top-50 (drops fallback rows). `gold_via_fallback` column in predictions_*.jsonl supports any further re-slicing.
