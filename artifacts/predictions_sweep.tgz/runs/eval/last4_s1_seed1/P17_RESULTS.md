# P17 — Reader Bottleneck Characterization

- pre-reg: METHODOLOGY_NOTE_P17.md (commits 37e3181 + 1a8a08c)
- subset: subset500_v2 (n_full=496, n_kept_primary=495)
  - excluded for short-distractors: 1
  - gold via fallback (`pos_item_ids[0]`): 140 qids
- model: Qwen/Qwen2.5-VL-7B-Instruct
- hardware: NVIDIA RTX 6000 Ada Generation  torch: 2.11.0+cu128  cuDNN SDP: disabled
- wall: 76.4 min  peak VRAM: 19.29 GB
- reader cache: unique=6435 / total_cells=6435 (reuse savings 0.0%)

## Plot

![acc vs k](acc_vs_k.png)

## Primary (full n)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 495 | 68.48% | [64.26, 72.42] | 156 |
| **k3_first** | 3 | first | 0 | 495 | 61.41% | [57.05, 65.60] | 191 |
| **k3_middle** | 3 | middle | 1 | 495 | 62.22% | [57.87, 66.38] | 187 |
| **k3_last** | 3 | last | 2 | 495 | 62.63% | [58.28, 66.78] | 185 |
| **k5_first** | 5 | first | 0 | 495 | 58.18% | [53.79, 62.45] | 207 |
| **k5_middle** | 5 | middle | 2 | 495 | 59.80% | [55.42, 64.03] | 199 |
| **k5_last** | 5 | last | 4 | 495 | 61.21% | [56.85, 65.40] | 192 |
| **k10_first** | 10 | first | 0 | 495 | 57.17% | [52.77, 61.46] | 212 |
| **k10_middle** | 10 | middle | 4 | 495 | 56.97% | [52.57, 61.26] | 213 |
| **k10_last** | 10 | last | 9 | 495 | 54.55% | [50.14, 58.88] | 225 |
| **k20_first** | 20 | first | 0 | 495 | 53.33% | [48.93, 57.69] | 231 |
| **k20_middle** | 20 | middle | 9 | 495 | 52.32% | [47.92, 56.69] | 236 |
| **k20_last** | 20 | last | 19 | 495 | 49.29% | [44.91, 53.69] | 251 |

## Sensitivity (exclude gold-via-fallback rows)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 355 | 74.65% | [69.88, 78.89] | 90 |
| **k3_first** | 3 | first | 0 | 355 | 66.48% | [61.41, 71.19] | 119 |
| **k3_middle** | 3 | middle | 1 | 355 | 67.89% | [62.86, 72.53] | 114 |
| **k3_last** | 3 | last | 2 | 355 | 68.45% | [63.44, 73.07] | 112 |
| **k5_first** | 5 | first | 0 | 355 | 64.23% | [59.11, 69.03] | 127 |
| **k5_middle** | 5 | middle | 2 | 355 | 64.79% | [59.69, 69.57] | 125 |
| **k5_last** | 5 | last | 4 | 355 | 67.61% | [62.57, 72.26] | 115 |
| **k10_first** | 10 | first | 0 | 355 | 62.54% | [57.39, 67.41] | 133 |
| **k10_middle** | 10 | middle | 4 | 355 | 62.25% | [57.11, 67.14] | 134 |
| **k10_last** | 10 | last | 9 | 355 | 60.00% | [54.82, 64.96] | 142 |
| **k20_first** | 20 | first | 0 | 355 | 58.31% | [53.12, 63.32] | 148 |
| **k20_middle** | 20 | middle | 9 | 355 | 56.34% | [51.14, 61.40] | 155 |
| **k20_last** | 20 | last | 19 | 355 | 53.24% | [48.04, 58.37] | 166 |

## Distractor / error analysis (primary)

Per-cell breakdown of error categories, as % of errors in that cell.

| cell | k | position | n_err | extraction_failed | distractor_lift | ambiguous_in_context | hallucinated | dlift_rank_median |
|------|---|----------|------:|------------------:|----------------:|---------------------:|-------------:|------------------:|
| k1 | 1 | - | 156 | 54.5% | 0.0% | 0.0% | 45.5% | - |
| k3_first | 3 | first | 191 | 36.1% | 22.0% | 7.9% | 34.0% | 0 |
| k3_middle | 3 | middle | 187 | 35.8% | 20.3% | 10.2% | 33.7% | 1 |
| k3_last | 3 | last | 185 | 37.8% | 17.8% | 10.3% | 34.1% | 1 |
| k5_first | 5 | first | 207 | 31.9% | 24.6% | 12.1% | 31.4% | 1 |
| k5_middle | 5 | middle | 199 | 30.2% | 26.6% | 12.1% | 31.2% | 1 |
| k5_last | 5 | last | 192 | 30.7% | 26.6% | 13.5% | 29.2% | 1 |
| k10_first | 10 | first | 212 | 23.1% | 36.8% | 16.0% | 24.1% | 3 |
| k10_middle | 10 | middle | 213 | 22.1% | 34.7% | 16.9% | 26.3% | 3 |
| k10_last | 10 | last | 225 | 20.9% | 36.0% | 17.3% | 25.8% | 3 |
| k20_first | 20 | first | 231 | 18.2% | 44.6% | 15.2% | 22.1% | 5 |
| k20_middle | 20 | middle | 236 | 15.3% | 43.6% | 16.5% | 24.6% | 5 |
| k20_last | 20 | last | 251 | 14.3% | 46.6% | 15.5% | 23.5% | 5 |

`dlift_rank_median` = median PreFLMR rank (within top-50) of the chosen distractor passage on `distractor_lift` errors. Lower = more semantically similar to the query.

## Notes

- Greedy 7B reader, original question text only, GOLD_IN.
- Distractor-bucket categorization uses case-insensitive ASCII-folded substring match (heuristic; under-counts paraphrases).
- Sensitivity table re-evaluates on the subset where the chosen gold actually appears in PreFLMR top-50 (drops fallback rows). `gold_via_fallback` column in predictions_*.jsonl supports any further re-slicing.
