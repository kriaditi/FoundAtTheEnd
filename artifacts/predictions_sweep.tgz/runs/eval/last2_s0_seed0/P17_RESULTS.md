# P17 — Reader Bottleneck Characterization

- pre-reg: METHODOLOGY_NOTE_P17.md (commits 37e3181 + 1a8a08c)
- subset: subset500_v2 (n_full=496, n_kept_primary=495)
  - excluded for short-distractors: 1
  - gold via fallback (`pos_item_ids[0]`): 140 qids
- model: Qwen/Qwen2.5-VL-7B-Instruct
- hardware: NVIDIA RTX 6000 Ada Generation  torch: 2.11.0+cu128  cuDNN SDP: disabled
- wall: 75.9 min  peak VRAM: 19.29 GB
- reader cache: unique=6435 / total_cells=6435 (reuse savings 0.0%)

## Plot

![acc vs k](acc_vs_k.png)

## Primary (full n)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 495 | 65.45% | [61.16, 69.51] | 171 |
| **k3_first** | 3 | first | 0 | 495 | 60.61% | [56.24, 64.81] | 195 |
| **k3_middle** | 3 | middle | 1 | 495 | 60.61% | [56.24, 64.81] | 195 |
| **k3_last** | 3 | last | 2 | 495 | 60.40% | [56.03, 64.62] | 196 |
| **k5_first** | 5 | first | 0 | 495 | 60.20% | [55.83, 64.42] | 197 |
| **k5_middle** | 5 | middle | 2 | 495 | 60.20% | [55.83, 64.42] | 197 |
| **k5_last** | 5 | last | 4 | 495 | 58.18% | [53.79, 62.45] | 207 |
| **k10_first** | 10 | first | 0 | 495 | 56.97% | [52.57, 61.26] | 213 |
| **k10_middle** | 10 | middle | 4 | 495 | 56.97% | [52.57, 61.26] | 213 |
| **k10_last** | 10 | last | 9 | 495 | 51.52% | [47.12, 55.89] | 240 |
| **k20_first** | 20 | first | 0 | 495 | 52.93% | [48.53, 57.29] | 233 |
| **k20_middle** | 20 | middle | 9 | 495 | 51.72% | [47.32, 56.09] | 239 |
| **k20_last** | 20 | last | 19 | 495 | 47.27% | [42.91, 51.68] | 261 |

## Sensitivity (exclude gold-via-fallback rows)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 355 | 71.83% | [66.94, 76.26] | 100 |
| **k3_first** | 3 | first | 0 | 355 | 65.07% | [59.97, 69.84] | 124 |
| **k3_middle** | 3 | middle | 1 | 355 | 65.63% | [60.55, 70.38] | 122 |
| **k3_last** | 3 | last | 2 | 355 | 64.79% | [59.69, 69.57] | 125 |
| **k5_first** | 5 | first | 0 | 355 | 64.79% | [59.69, 69.57] | 125 |
| **k5_middle** | 5 | middle | 2 | 355 | 65.07% | [59.97, 69.84] | 124 |
| **k5_last** | 5 | last | 4 | 355 | 62.54% | [57.39, 67.41] | 133 |
| **k10_first** | 10 | first | 0 | 355 | 60.85% | [55.68, 65.78] | 139 |
| **k10_middle** | 10 | middle | 4 | 355 | 61.69% | [56.53, 66.60] | 136 |
| **k10_last** | 10 | last | 9 | 355 | 56.34% | [51.14, 61.40] | 155 |
| **k20_first** | 20 | first | 0 | 355 | 57.18% | [51.99, 62.23] | 152 |
| **k20_middle** | 20 | middle | 9 | 355 | 56.06% | [50.86, 61.13] | 156 |
| **k20_last** | 20 | last | 19 | 355 | 52.39% | [47.20, 57.54] | 169 |

## Distractor / error analysis (primary)

Per-cell breakdown of error categories, as % of errors in that cell.

| cell | k | position | n_err | extraction_failed | distractor_lift | ambiguous_in_context | hallucinated | dlift_rank_median |
|------|---|----------|------:|------------------:|----------------:|---------------------:|-------------:|------------------:|
| k1 | 1 | - | 171 | 48.0% | 0.0% | 0.0% | 52.0% | - |
| k3_first | 3 | first | 195 | 35.9% | 19.0% | 8.7% | 36.4% | 1 |
| k3_middle | 3 | middle | 195 | 34.9% | 16.9% | 10.8% | 37.4% | 1 |
| k3_last | 3 | last | 196 | 33.7% | 19.4% | 9.2% | 37.8% | 1 |
| k5_first | 5 | first | 197 | 28.9% | 22.8% | 10.2% | 38.1% | 1 |
| k5_middle | 5 | middle | 197 | 29.4% | 22.3% | 11.7% | 36.5% | 1 |
| k5_last | 5 | last | 207 | 27.1% | 26.6% | 10.6% | 35.7% | 1 |
| k10_first | 10 | first | 213 | 22.1% | 32.9% | 13.6% | 31.5% | 2 |
| k10_middle | 10 | middle | 213 | 22.5% | 31.5% | 14.6% | 31.5% | 2 |
| k10_last | 10 | last | 240 | 17.9% | 37.1% | 14.2% | 30.8% | 2 |
| k20_first | 20 | first | 233 | 18.9% | 37.3% | 15.9% | 27.9% | 4 |
| k20_middle | 20 | middle | 239 | 17.2% | 41.0% | 15.5% | 26.4% | 3 |
| k20_last | 20 | last | 261 | 13.8% | 47.1% | 14.2% | 24.9% | 4 |

`dlift_rank_median` = median PreFLMR rank (within top-50) of the chosen distractor passage on `distractor_lift` errors. Lower = more semantically similar to the query.

## Notes

- Greedy 7B reader, original question text only, GOLD_IN.
- Distractor-bucket categorization uses case-insensitive ASCII-folded substring match (heuristic; under-counts paraphrases).
- Sensitivity table re-evaluates on the subset where the chosen gold actually appears in PreFLMR top-50 (drops fallback rows). `gold_via_fallback` column in predictions_*.jsonl supports any further re-slicing.
