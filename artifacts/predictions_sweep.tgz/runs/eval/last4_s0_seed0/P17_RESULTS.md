# P17 — Reader Bottleneck Characterization

- pre-reg: METHODOLOGY_NOTE_P17.md (commits 37e3181 + 1a8a08c)
- subset: subset500_v2 (n_full=496, n_kept_primary=495)
  - excluded for short-distractors: 1
  - gold via fallback (`pos_item_ids[0]`): 140 qids
- model: Qwen/Qwen2.5-VL-7B-Instruct
- hardware: NVIDIA RTX 6000 Ada Generation  torch: 2.11.0+cu128  cuDNN SDP: disabled
- wall: 77.8 min  peak VRAM: 19.29 GB
- reader cache: unique=6435 / total_cells=6435 (reuse savings 0.0%)

## Plot

![acc vs k](acc_vs_k.png)

## Primary (full n)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 495 | 63.64% | [59.31, 67.75] | 180 |
| **k3_first** | 3 | first | 0 | 495 | 58.18% | [53.79, 62.45] | 207 |
| **k3_middle** | 3 | middle | 1 | 495 | 61.21% | [56.85, 65.40] | 192 |
| **k3_last** | 3 | last | 2 | 495 | 59.39% | [55.01, 63.63] | 201 |
| **k5_first** | 5 | first | 0 | 495 | 56.57% | [52.17, 60.87] | 215 |
| **k5_middle** | 5 | middle | 2 | 495 | 57.37% | [52.98, 61.66] | 211 |
| **k5_last** | 5 | last | 4 | 495 | 54.95% | [50.54, 59.28] | 223 |
| **k10_first** | 10 | first | 0 | 495 | 54.34% | [49.94, 58.68] | 226 |
| **k10_middle** | 10 | middle | 4 | 495 | 54.34% | [49.94, 58.68] | 226 |
| **k10_last** | 10 | last | 9 | 495 | 50.71% | [46.31, 55.09] | 244 |
| **k20_first** | 20 | first | 0 | 495 | 49.70% | [45.31, 54.09] | 249 |
| **k20_middle** | 20 | middle | 9 | 495 | 49.29% | [44.91, 53.69] | 251 |
| **k20_last** | 20 | last | 19 | 495 | 44.24% | [39.93, 48.65] | 276 |

## Sensitivity (exclude gold-via-fallback rows)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 355 | 68.17% | [63.15, 72.80] | 113 |
| **k3_first** | 3 | first | 0 | 355 | 61.97% | [56.82, 66.87] | 135 |
| **k3_middle** | 3 | middle | 1 | 355 | 66.76% | [61.70, 71.46] | 118 |
| **k3_last** | 3 | last | 2 | 355 | 64.23% | [59.11, 69.03] | 127 |
| **k5_first** | 5 | first | 0 | 355 | 59.72% | [54.54, 64.69] | 143 |
| **k5_middle** | 5 | middle | 2 | 355 | 60.85% | [55.68, 65.78] | 139 |
| **k5_last** | 5 | last | 4 | 355 | 58.03% | [52.84, 63.05] | 149 |
| **k10_first** | 10 | first | 0 | 355 | 59.15% | [53.97, 64.14] | 145 |
| **k10_middle** | 10 | middle | 4 | 355 | 57.75% | [52.55, 62.78] | 150 |
| **k10_last** | 10 | last | 9 | 355 | 54.65% | [49.45, 59.75] | 161 |
| **k20_first** | 20 | first | 0 | 355 | 54.08% | [48.88, 59.20] | 163 |
| **k20_middle** | 20 | middle | 9 | 355 | 53.52% | [48.32, 58.64] | 165 |
| **k20_last** | 20 | last | 19 | 355 | 47.89% | [42.74, 53.08] | 185 |

## Distractor / error analysis (primary)

Per-cell breakdown of error categories, as % of errors in that cell.

| cell | k | position | n_err | extraction_failed | distractor_lift | ambiguous_in_context | hallucinated | dlift_rank_median |
|------|---|----------|------:|------------------:|----------------:|---------------------:|-------------:|------------------:|
| k1 | 1 | - | 180 | 47.2% | 0.0% | 0.0% | 52.8% | - |
| k3_first | 3 | first | 207 | 31.9% | 22.2% | 7.7% | 38.2% | 0 |
| k3_middle | 3 | middle | 192 | 34.9% | 18.8% | 7.3% | 39.1% | 0 |
| k3_last | 3 | last | 201 | 34.8% | 19.4% | 8.0% | 37.8% | 1 |
| k5_first | 5 | first | 215 | 28.8% | 25.1% | 10.7% | 35.3% | 1 |
| k5_middle | 5 | middle | 211 | 30.8% | 25.1% | 9.5% | 34.6% | 1 |
| k5_last | 5 | last | 223 | 28.7% | 26.9% | 10.3% | 34.1% | 1 |
| k10_first | 10 | first | 226 | 23.9% | 37.2% | 11.1% | 27.9% | 2 |
| k10_middle | 10 | middle | 226 | 23.5% | 35.0% | 13.3% | 28.3% | 2 |
| k10_last | 10 | last | 244 | 20.5% | 37.7% | 14.8% | 27.0% | 3 |
| k20_first | 20 | first | 249 | 17.7% | 41.4% | 15.7% | 25.3% | 4 |
| k20_middle | 20 | middle | 251 | 17.9% | 41.4% | 16.3% | 24.3% | 4 |
| k20_last | 20 | last | 276 | 13.4% | 44.9% | 16.3% | 25.4% | 4 |

`dlift_rank_median` = median PreFLMR rank (within top-50) of the chosen distractor passage on `distractor_lift` errors. Lower = more semantically similar to the query.

## Notes

- Greedy 7B reader, original question text only, GOLD_IN.
- Distractor-bucket categorization uses case-insensitive ASCII-folded substring match (heuristic; under-counts paraphrases).
- Sensitivity table re-evaluates on the subset where the chosen gold actually appears in PreFLMR top-50 (drops fallback rows). `gold_via_fallback` column in predictions_*.jsonl supports any further re-slicing.
