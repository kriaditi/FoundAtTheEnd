# P17 — Reader Bottleneck Characterization

- pre-reg: METHODOLOGY_NOTE_P17.md (commits 37e3181 + 1a8a08c)
- subset: subset500_v2 (n_full=496, n_kept_primary=495)
  - excluded for short-distractors: 1
  - gold via fallback (`pos_item_ids[0]`): 140 qids
- model: Qwen/Qwen2.5-VL-7B-Instruct
- hardware: NVIDIA RTX 6000 Ada Generation  torch: 2.11.0+cu128  cuDNN SDP: disabled
- wall: 75.8 min  peak VRAM: 19.29 GB
- reader cache: unique=6435 / total_cells=6435 (reuse savings 0.0%)

## Plot

![acc vs k](acc_vs_k.png)

## Primary (full n)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 495 | 61.01% | [56.64, 65.21] | 193 |
| **k3_first** | 3 | first | 0 | 495 | 57.17% | [52.77, 61.46] | 212 |
| **k3_middle** | 3 | middle | 1 | 495 | 58.59% | [54.20, 62.84] | 205 |
| **k3_last** | 3 | last | 2 | 495 | 60.40% | [56.03, 64.62] | 196 |
| **k5_first** | 5 | first | 0 | 495 | 55.15% | [50.75, 59.48] | 222 |
| **k5_middle** | 5 | middle | 2 | 495 | 57.78% | [53.38, 62.05] | 209 |
| **k5_last** | 5 | last | 4 | 495 | 57.17% | [52.77, 61.46] | 212 |
| **k10_first** | 10 | first | 0 | 495 | 50.91% | [46.52, 55.29] | 243 |
| **k10_middle** | 10 | middle | 4 | 495 | 52.32% | [47.92, 56.69] | 236 |
| **k10_last** | 10 | last | 9 | 495 | 52.73% | [48.32, 57.09] | 234 |
| **k20_first** | 20 | first | 0 | 495 | 47.27% | [42.91, 51.68] | 261 |
| **k20_middle** | 20 | middle | 9 | 495 | 47.68% | [43.31, 52.08] | 259 |
| **k20_last** | 20 | last | 19 | 495 | 47.88% | [43.51, 52.28] | 258 |

## Sensitivity (exclude gold-via-fallback rows)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 355 | 65.63% | [60.55, 70.38] | 122 |
| **k3_first** | 3 | first | 0 | 355 | 60.28% | [55.11, 65.24] | 141 |
| **k3_middle** | 3 | middle | 1 | 355 | 62.54% | [57.39, 67.41] | 133 |
| **k3_last** | 3 | last | 2 | 355 | 65.35% | [60.26, 70.11] | 123 |
| **k5_first** | 5 | first | 0 | 355 | 59.15% | [53.97, 64.14] | 145 |
| **k5_middle** | 5 | middle | 2 | 355 | 62.82% | [57.68, 67.68] | 132 |
| **k5_last** | 5 | last | 4 | 355 | 61.69% | [56.53, 66.60] | 136 |
| **k10_first** | 10 | first | 0 | 355 | 55.49% | [50.29, 60.58] | 158 |
| **k10_middle** | 10 | middle | 4 | 355 | 56.62% | [51.42, 61.68] | 154 |
| **k10_last** | 10 | last | 9 | 355 | 57.18% | [51.99, 62.23] | 152 |
| **k20_first** | 20 | first | 0 | 355 | 52.11% | [46.92, 57.26] | 170 |
| **k20_middle** | 20 | middle | 9 | 355 | 51.27% | [46.08, 56.43] | 173 |
| **k20_last** | 20 | last | 19 | 355 | 52.39% | [47.20, 57.54] | 169 |

## Distractor / error analysis (primary)

Per-cell breakdown of error categories, as % of errors in that cell.

| cell | k | position | n_err | extraction_failed | distractor_lift | ambiguous_in_context | hallucinated | dlift_rank_median |
|------|---|----------|------:|------------------:|----------------:|---------------------:|-------------:|------------------:|
| k1 | 1 | - | 193 | 48.7% | 0.0% | 0.0% | 51.3% | - |
| k3_first | 3 | first | 212 | 29.7% | 21.7% | 11.8% | 36.8% | 0 |
| k3_middle | 3 | middle | 205 | 30.7% | 16.6% | 13.7% | 39.0% | 1 |
| k3_last | 3 | last | 196 | 33.7% | 15.8% | 11.7% | 38.8% | 0 |
| k5_first | 5 | first | 222 | 26.6% | 27.5% | 12.2% | 33.8% | 2 |
| k5_middle | 5 | middle | 209 | 29.7% | 25.8% | 12.0% | 32.5% | 1 |
| k5_last | 5 | last | 212 | 30.2% | 22.6% | 12.3% | 34.9% | 1 |
| k10_first | 10 | first | 243 | 21.4% | 36.2% | 13.6% | 28.8% | 4 |
| k10_middle | 10 | middle | 236 | 22.0% | 32.2% | 16.5% | 29.2% | 3 |
| k10_last | 10 | last | 234 | 23.1% | 32.5% | 15.0% | 29.5% | 3 |
| k20_first | 20 | first | 261 | 14.2% | 46.4% | 15.3% | 24.1% | 5 |
| k20_middle | 20 | middle | 259 | 17.8% | 42.1% | 16.6% | 23.6% | 5 |
| k20_last | 20 | last | 258 | 15.9% | 43.0% | 16.3% | 24.8% | 5 |

`dlift_rank_median` = median PreFLMR rank (within top-50) of the chosen distractor passage on `distractor_lift` errors. Lower = more semantically similar to the query.

## Notes

- Greedy 7B reader, original question text only, GOLD_IN.
- Distractor-bucket categorization uses case-insensitive ASCII-folded substring match (heuristic; under-counts paraphrases).
- Sensitivity table re-evaluates on the subset where the chosen gold actually appears in PreFLMR top-50 (drops fallback rows). `gold_via_fallback` column in predictions_*.jsonl supports any further re-slicing.
