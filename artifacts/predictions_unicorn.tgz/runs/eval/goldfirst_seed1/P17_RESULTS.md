# P17 — Reader Bottleneck Characterization

- pre-reg: METHODOLOGY_NOTE_P17.md (commits 37e3181 + 1a8a08c)
- subset: subset500_v2 (n_full=496, n_kept_primary=495)
  - excluded for short-distractors: 1
  - gold via fallback (`pos_item_ids[0]`): 140 qids
- model: Qwen/Qwen2.5-VL-7B-Instruct
- hardware: NVIDIA RTX 6000 Ada Generation  torch: 2.11.0+cu128  cuDNN SDP: disabled
- wall: 0.1 min  peak VRAM: 0.00 GB
- reader cache: unique=6435 / total_cells=6435 (reuse savings 0.0%)

## Plot

![acc vs k](acc_vs_k.png)

## Primary (full n)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 495 | 68.48% | [64.26, 72.42] | 156 |
| **k3_first** | 3 | first | 0 | 495 | 69.49% | [65.30, 73.39] | 151 |
| **k3_middle** | 3 | middle | 1 | 495 | 16.16% | [13.18, 19.66] | 415 |
| **k3_last** | 3 | last | 2 | 495 | 15.35% | [12.45, 18.80] | 419 |
| **k5_first** | 5 | first | 0 | 495 | 69.49% | [65.30, 73.39] | 151 |
| **k5_middle** | 5 | middle | 2 | 495 | 15.15% | [12.26, 18.58] | 420 |
| **k5_last** | 5 | last | 4 | 495 | 14.55% | [11.71, 17.92] | 423 |
| **k10_first** | 10 | first | 0 | 495 | 69.29% | [65.09, 73.20] | 152 |
| **k10_middle** | 10 | middle | 4 | 495 | 14.95% | [12.08, 18.36] | 421 |
| **k10_last** | 10 | last | 9 | 495 | 15.15% | [12.26, 18.58] | 420 |
| **k20_first** | 20 | first | 0 | 495 | 69.09% | [64.89, 73.00] | 153 |
| **k20_middle** | 20 | middle | 9 | 495 | 13.94% | [11.16, 17.27] | 426 |
| **k20_last** | 20 | last | 19 | 495 | 13.94% | [11.16, 17.27] | 426 |

## Sensitivity (exclude gold-via-fallback rows)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 355 | 72.39% | [67.52, 76.79] | 98 |
| **k3_first** | 3 | first | 0 | 355 | 72.39% | [67.52, 76.79] | 98 |
| **k3_middle** | 3 | middle | 1 | 355 | 19.15% | [15.40, 23.57] | 287 |
| **k3_last** | 3 | last | 2 | 355 | 18.03% | [14.38, 22.36] | 291 |
| **k5_first** | 5 | first | 0 | 355 | 72.68% | [67.82, 77.05] | 97 |
| **k5_middle** | 5 | middle | 2 | 355 | 18.31% | [14.63, 22.67] | 290 |
| **k5_last** | 5 | last | 4 | 355 | 17.46% | [13.87, 21.76] | 293 |
| **k10_first** | 10 | first | 0 | 355 | 71.83% | [66.94, 76.26] | 100 |
| **k10_middle** | 10 | middle | 4 | 355 | 17.46% | [13.87, 21.76] | 293 |
| **k10_last** | 10 | last | 9 | 355 | 17.75% | [14.12, 22.06] | 292 |
| **k20_first** | 20 | first | 0 | 355 | 72.11% | [67.23, 76.52] | 99 |
| **k20_middle** | 20 | middle | 9 | 355 | 16.90% | [13.36, 21.15] | 295 |
| **k20_last** | 20 | last | 19 | 355 | 16.90% | [13.36, 21.15] | 295 |

## Distractor / error analysis (primary)

Per-cell breakdown of error categories, as % of errors in that cell.

| cell | k | position | n_err | extraction_failed | distractor_lift | ambiguous_in_context | hallucinated | dlift_rank_median |
|------|---|----------|------:|------------------:|----------------:|---------------------:|-------------:|------------------:|
| k1 | 1 | - | 156 | 64.1% | 0.0% | 0.0% | 35.9% | - |
| k3_first | 3 | first | 151 | 47.7% | 3.3% | 13.9% | 35.1% | 0 |
| k3_middle | 3 | middle | 415 | 1.7% | 54.2% | 8.7% | 35.4% | 0 |
| k3_last | 3 | last | 419 | 1.4% | 54.2% | 8.1% | 36.3% | 0 |
| k5_first | 5 | first | 151 | 41.7% | 5.3% | 18.5% | 34.4% | 2 |
| k5_middle | 5 | middle | 420 | 1.9% | 57.9% | 8.3% | 31.9% | 0 |
| k5_last | 5 | last | 423 | 1.7% | 57.9% | 8.5% | 31.9% | 0 |
| k10_first | 10 | first | 152 | 40.1% | 8.6% | 27.0% | 24.3% | 4 |
| k10_middle | 10 | middle | 421 | 1.2% | 60.6% | 8.6% | 29.7% | 0 |
| k10_last | 10 | last | 420 | 1.0% | 61.7% | 8.3% | 29.0% | 0 |
| k20_first | 20 | first | 153 | 35.3% | 10.5% | 29.4% | 24.8% | 6 |
| k20_middle | 20 | middle | 426 | 0.7% | 65.0% | 9.4% | 24.9% | 0 |
| k20_last | 20 | last | 426 | 0.5% | 65.0% | 9.4% | 25.1% | 0 |

`dlift_rank_median` = median PreFLMR rank (within top-50) of the chosen distractor passage on `distractor_lift` errors. Lower = more semantically similar to the query.

## Notes

- Greedy 7B reader, original question text only, GOLD_IN.
- Distractor-bucket categorization uses case-insensitive ASCII-folded substring match (heuristic; under-counts paraphrases).
- Sensitivity table re-evaluates on the subset where the chosen gold actually appears in PreFLMR top-50 (drops fallback rows). `gold_via_fallback` column in predictions_*.jsonl supports any further re-slicing.
