# P17 — Reader Bottleneck Characterization

- pre-reg: METHODOLOGY_NOTE_P17.md (commits 37e3181 + 1a8a08c)
- subset: subset500_v2 (n_full=496, n_kept_primary=495)
  - excluded for short-distractors: 1
  - gold via fallback (`pos_item_ids[0]`): 140 qids
- model: Qwen/Qwen2.5-VL-7B-Instruct
- hardware: NVIDIA RTX 6000 Ada Generation  torch: 2.11.0+cu128  cuDNN SDP: disabled
- wall: 76.2 min  peak VRAM: 19.29 GB
- reader cache: unique=6435 / total_cells=6435 (reuse savings 0.0%)

## Plot

![acc vs k](acc_vs_k.png)

## Primary (full n)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 495 | 63.23% | [58.90, 67.36] | 182 |
| **k3_first** | 3 | first | 0 | 495 | 60.61% | [56.24, 64.81] | 195 |
| **k3_middle** | 3 | middle | 1 | 495 | 59.39% | [55.01, 63.63] | 201 |
| **k3_last** | 3 | last | 2 | 495 | 59.60% | [55.22, 63.83] | 200 |
| **k5_first** | 5 | first | 0 | 495 | 59.39% | [55.01, 63.63] | 201 |
| **k5_middle** | 5 | middle | 2 | 495 | 59.60% | [55.22, 63.83] | 200 |
| **k5_last** | 5 | last | 4 | 495 | 57.78% | [53.38, 62.05] | 209 |
| **k10_first** | 10 | first | 0 | 495 | 55.56% | [51.15, 59.87] | 220 |
| **k10_middle** | 10 | middle | 4 | 495 | 56.57% | [52.17, 60.87] | 215 |
| **k10_last** | 10 | last | 9 | 495 | 54.55% | [50.14, 58.88] | 225 |
| **k20_first** | 20 | first | 0 | 495 | 52.12% | [47.72, 56.49] | 237 |
| **k20_middle** | 20 | middle | 9 | 495 | 54.14% | [49.74, 58.48] | 227 |
| **k20_last** | 20 | last | 19 | 495 | 52.73% | [48.32, 57.09] | 234 |

## Sensitivity (exclude gold-via-fallback rows)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 355 | 67.04% | [61.99, 71.73] | 117 |
| **k3_first** | 3 | first | 0 | 355 | 63.94% | [58.82, 68.76] | 128 |
| **k3_middle** | 3 | middle | 1 | 355 | 62.82% | [57.68, 67.68] | 132 |
| **k3_last** | 3 | last | 2 | 355 | 63.10% | [57.96, 67.95] | 131 |
| **k5_first** | 5 | first | 0 | 355 | 62.54% | [57.39, 67.41] | 133 |
| **k5_middle** | 5 | middle | 2 | 355 | 63.10% | [57.96, 67.95] | 131 |
| **k5_last** | 5 | last | 4 | 355 | 61.41% | [56.25, 66.32] | 137 |
| **k10_first** | 10 | first | 0 | 355 | 59.15% | [53.97, 64.14] | 145 |
| **k10_middle** | 10 | middle | 4 | 355 | 60.28% | [55.11, 65.24] | 141 |
| **k10_last** | 10 | last | 9 | 355 | 58.59% | [53.40, 63.60] | 147 |
| **k20_first** | 20 | first | 0 | 355 | 55.49% | [50.29, 60.58] | 158 |
| **k20_middle** | 20 | middle | 9 | 355 | 57.18% | [51.99, 62.23] | 152 |
| **k20_last** | 20 | last | 19 | 355 | 56.90% | [51.70, 61.95] | 153 |

## Distractor / error analysis (primary)

Per-cell breakdown of error categories, as % of errors in that cell.

| cell | k | position | n_err | extraction_failed | distractor_lift | ambiguous_in_context | hallucinated | dlift_rank_median |
|------|---|----------|------:|------------------:|----------------:|---------------------:|-------------:|------------------:|
| k1 | 1 | - | 182 | 56.0% | 0.0% | 0.0% | 44.0% | - |
| k3_first | 3 | first | 195 | 35.9% | 17.9% | 12.3% | 33.8% | 0 |
| k3_middle | 3 | middle | 201 | 34.3% | 18.4% | 10.9% | 36.3% | 0 |
| k3_last | 3 | last | 200 | 37.0% | 18.0% | 10.5% | 34.5% | 0 |
| k5_first | 5 | first | 201 | 31.3% | 24.4% | 12.9% | 31.3% | 1 |
| k5_middle | 5 | middle | 200 | 31.5% | 23.5% | 12.0% | 33.0% | 1 |
| k5_last | 5 | last | 209 | 30.1% | 23.0% | 12.9% | 34.0% | 1 |
| k10_first | 10 | first | 220 | 23.2% | 30.9% | 17.3% | 28.6% | 2 |
| k10_middle | 10 | middle | 215 | 23.7% | 30.2% | 17.7% | 28.4% | 2 |
| k10_last | 10 | last | 225 | 21.3% | 29.8% | 17.3% | 31.6% | 2 |
| k20_first | 20 | first | 237 | 16.9% | 43.0% | 18.6% | 21.5% | 5 |
| k20_middle | 20 | middle | 227 | 18.9% | 38.8% | 18.5% | 23.8% | 5 |
| k20_last | 20 | last | 234 | 20.1% | 39.3% | 17.9% | 22.6% | 5 |

`dlift_rank_median` = median PreFLMR rank (within top-50) of the chosen distractor passage on `distractor_lift` errors. Lower = more semantically similar to the query.

## Notes

- Greedy 7B reader, original question text only, GOLD_IN.
- Distractor-bucket categorization uses case-insensitive ASCII-folded substring match (heuristic; under-counts paraphrases).
- Sensitivity table re-evaluates on the subset where the chosen gold actually appears in PreFLMR top-50 (drops fallback rows). `gold_via_fallback` column in predictions_*.jsonl supports any further re-slicing.
