# P17 — Reader Bottleneck Characterization

- pre-reg: METHODOLOGY_NOTE_P17.md (commits 37e3181 + 1a8a08c)
- subset: subset500_v2 (n_full=496, n_kept_primary=495)
  - excluded for short-distractors: 1
  - gold via fallback (`pos_item_ids[0]`): 140 qids
- model: Qwen/Qwen2.5-VL-7B-Instruct
- hardware: NVIDIA RTX 6000 Ada Generation  torch: 2.11.0+cu128  cuDNN SDP: disabled
- wall: 0.1 min  peak VRAM: 0.00 GB
- reader cache: unique=6435 / total_cells=6435 (reuse savings 0.0%)

## Plot

![acc vs k](acc_vs_k.png)

## Primary (full n)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 495 | 62.83% | [58.49, 66.97] | 184 |
| **k3_first** | 3 | first | 0 | 495 | 58.79% | [54.40, 63.04] | 204 |
| **k3_middle** | 3 | middle | 1 | 495 | 58.99% | [54.60, 63.24] | 203 |
| **k3_last** | 3 | last | 2 | 495 | 59.39% | [55.01, 63.63] | 201 |
| **k5_first** | 5 | first | 0 | 495 | 57.58% | [53.18, 61.85] | 210 |
| **k5_middle** | 5 | middle | 2 | 495 | 56.77% | [52.37, 61.06] | 214 |
| **k5_last** | 5 | last | 4 | 495 | 56.97% | [52.57, 61.26] | 213 |
| **k10_first** | 10 | first | 0 | 495 | 52.12% | [47.72, 56.49] | 237 |
| **k10_middle** | 10 | middle | 4 | 495 | 53.33% | [48.93, 57.69] | 231 |
| **k10_last** | 10 | last | 9 | 495 | 51.31% | [46.92, 55.69] | 241 |
| **k20_first** | 20 | first | 0 | 495 | 46.87% | [42.51, 51.27] | 263 |
| **k20_middle** | 20 | middle | 9 | 495 | 46.87% | [42.51, 51.27] | 263 |
| **k20_last** | 20 | last | 19 | 495 | 47.07% | [42.71, 51.47] | 262 |

## Sensitivity (exclude gold-via-fallback rows)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 355 | 66.76% | [61.70, 71.46] | 118 |
| **k3_first** | 3 | first | 0 | 355 | 61.97% | [56.82, 66.87] | 135 |
| **k3_middle** | 3 | middle | 1 | 355 | 62.25% | [57.11, 67.14] | 134 |
| **k3_last** | 3 | last | 2 | 355 | 61.97% | [56.82, 66.87] | 135 |
| **k5_first** | 5 | first | 0 | 355 | 61.41% | [56.25, 66.32] | 137 |
| **k5_middle** | 5 | middle | 2 | 355 | 60.56% | [55.39, 65.51] | 140 |
| **k5_last** | 5 | last | 4 | 355 | 60.56% | [55.39, 65.51] | 140 |
| **k10_first** | 10 | first | 0 | 355 | 55.49% | [50.29, 60.58] | 158 |
| **k10_middle** | 10 | middle | 4 | 355 | 56.90% | [51.70, 61.95] | 153 |
| **k10_last** | 10 | last | 9 | 355 | 55.21% | [50.01, 60.30] | 159 |
| **k20_first** | 20 | first | 0 | 355 | 50.70% | [45.52, 55.87] | 175 |
| **k20_middle** | 20 | middle | 9 | 355 | 50.70% | [45.52, 55.87] | 175 |
| **k20_last** | 20 | last | 19 | 355 | 49.58% | [44.41, 54.76] | 179 |

## Distractor / error analysis (primary)

Per-cell breakdown of error categories, as % of errors in that cell.

| cell | k | position | n_err | extraction_failed | distractor_lift | ambiguous_in_context | hallucinated | dlift_rank_median |
|------|---|----------|------:|------------------:|----------------:|---------------------:|-------------:|------------------:|
| k1 | 1 | - | 184 | 48.4% | 0.0% | 0.0% | 51.6% | - |
| k3_first | 3 | first | 204 | 29.9% | 20.6% | 10.3% | 39.2% | 0 |
| k3_middle | 3 | middle | 203 | 33.5% | 17.7% | 10.8% | 37.9% | 0 |
| k3_last | 3 | last | 201 | 35.3% | 19.9% | 10.4% | 34.3% | 0 |
| k5_first | 5 | first | 210 | 25.2% | 25.7% | 11.4% | 37.6% | 2 |
| k5_middle | 5 | middle | 214 | 28.5% | 25.2% | 11.7% | 34.6% | 1 |
| k5_last | 5 | last | 213 | 28.6% | 25.8% | 10.3% | 35.2% | 1 |
| k10_first | 10 | first | 237 | 18.6% | 40.9% | 11.4% | 29.1% | 3 |
| k10_middle | 10 | middle | 231 | 22.1% | 33.3% | 14.7% | 29.9% | 3 |
| k10_last | 10 | last | 241 | 19.5% | 37.3% | 14.1% | 29.0% | 3 |
| k20_first | 20 | first | 263 | 14.8% | 44.5% | 16.0% | 24.7% | 5 |
| k20_middle | 20 | middle | 263 | 15.6% | 42.2% | 15.6% | 26.6% | 4 |
| k20_last | 20 | last | 262 | 14.5% | 45.8% | 15.6% | 24.0% | 5 |

`dlift_rank_median` = median PreFLMR rank (within top-50) of the chosen distractor passage on `distractor_lift` errors. Lower = more semantically similar to the query.

## Notes

- Greedy 7B reader, original question text only, GOLD_IN.
- Distractor-bucket categorization uses case-insensitive ASCII-folded substring match (heuristic; under-counts paraphrases).
- Sensitivity table re-evaluates on the subset where the chosen gold actually appears in PreFLMR top-50 (drops fallback rows). `gold_via_fallback` column in predictions_*.jsonl supports any further re-slicing.
