# P17 — Reader Bottleneck Characterization

- pre-reg: METHODOLOGY_NOTE_P17.md (commits 37e3181 + 1a8a08c)
- subset: subset500_v2 (n_full=496, n_kept_primary=495)
  - excluded for short-distractors: 1
  - gold via fallback (`pos_item_ids[0]`): 140 qids
- model: Qwen/Qwen2.5-VL-7B-Instruct
- hardware: NVIDIA RTX 6000 Ada Generation  torch: 2.11.0+cu128  cuDNN SDP: disabled
- wall: 75.5 min  peak VRAM: 19.29 GB
- reader cache: unique=6435 / total_cells=6435 (reuse savings 0.0%)

## Plot

![acc vs k](acc_vs_k.png)

## Primary (full n)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 495 | 65.05% | [60.75, 69.12] | 173 |
| **k3_first** | 3 | first | 0 | 495 | 58.18% | [53.79, 62.45] | 207 |
| **k3_middle** | 3 | middle | 1 | 495 | 59.60% | [55.22, 63.83] | 200 |
| **k3_last** | 3 | last | 2 | 495 | 61.41% | [57.05, 65.60] | 191 |
| **k5_first** | 5 | first | 0 | 495 | 57.98% | [53.59, 62.25] | 208 |
| **k5_middle** | 5 | middle | 2 | 495 | 59.19% | [54.81, 63.43] | 202 |
| **k5_last** | 5 | last | 4 | 495 | 59.39% | [55.01, 63.63] | 201 |
| **k10_first** | 10 | first | 0 | 495 | 54.55% | [50.14, 58.88] | 225 |
| **k10_middle** | 10 | middle | 4 | 495 | 56.77% | [52.37, 61.06] | 214 |
| **k10_last** | 10 | last | 9 | 495 | 56.16% | [51.76, 60.47] | 217 |
| **k20_first** | 20 | first | 0 | 495 | 54.14% | [49.74, 58.48] | 227 |
| **k20_middle** | 20 | middle | 9 | 495 | 52.73% | [48.32, 57.09] | 234 |
| **k20_last** | 20 | last | 19 | 495 | 50.10% | [45.71, 54.49] | 247 |

## Sensitivity (exclude gold-via-fallback rows)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 355 | 68.73% | [63.73, 73.33] | 111 |
| **k3_first** | 3 | first | 0 | 355 | 62.25% | [57.11, 67.14] | 134 |
| **k3_middle** | 3 | middle | 1 | 355 | 64.51% | [59.40, 69.31] | 126 |
| **k3_last** | 3 | last | 2 | 355 | 65.63% | [60.55, 70.38] | 122 |
| **k5_first** | 5 | first | 0 | 355 | 61.97% | [56.82, 66.87] | 135 |
| **k5_middle** | 5 | middle | 2 | 355 | 63.94% | [58.82, 68.76] | 128 |
| **k5_last** | 5 | last | 4 | 355 | 63.94% | [58.82, 68.76] | 128 |
| **k10_first** | 10 | first | 0 | 355 | 58.31% | [53.12, 63.32] | 148 |
| **k10_middle** | 10 | middle | 4 | 355 | 61.97% | [56.82, 66.87] | 135 |
| **k10_last** | 10 | last | 9 | 355 | 60.28% | [55.11, 65.24] | 141 |
| **k20_first** | 20 | first | 0 | 355 | 60.56% | [55.39, 65.51] | 140 |
| **k20_middle** | 20 | middle | 9 | 355 | 57.18% | [51.99, 62.23] | 152 |
| **k20_last** | 20 | last | 19 | 355 | 54.65% | [49.45, 59.75] | 161 |

## Distractor / error analysis (primary)

Per-cell breakdown of error categories, as % of errors in that cell.

| cell | k | position | n_err | extraction_failed | distractor_lift | ambiguous_in_context | hallucinated | dlift_rank_median |
|------|---|----------|------:|------------------:|----------------:|---------------------:|-------------:|------------------:|
| k1 | 1 | - | 173 | 56.6% | 0.0% | 0.0% | 43.4% | - |
| k3_first | 3 | first | 207 | 30.9% | 19.8% | 13.0% | 36.2% | 0 |
| k3_middle | 3 | middle | 200 | 36.5% | 18.0% | 12.0% | 33.5% | 0 |
| k3_last | 3 | last | 191 | 38.2% | 17.3% | 13.1% | 31.4% | 0 |
| k5_first | 5 | first | 208 | 26.9% | 27.9% | 14.9% | 30.3% | 1 |
| k5_middle | 5 | middle | 202 | 32.7% | 22.3% | 16.8% | 28.2% | 1 |
| k5_last | 5 | last | 201 | 29.9% | 22.9% | 17.9% | 29.4% | 1 |
| k10_first | 10 | first | 225 | 20.4% | 34.7% | 16.9% | 28.0% | 3 |
| k10_middle | 10 | middle | 214 | 22.4% | 32.7% | 19.6% | 25.2% | 3 |
| k10_last | 10 | last | 217 | 22.6% | 32.3% | 17.5% | 27.6% | 3 |
| k20_first | 20 | first | 227 | 17.2% | 44.9% | 15.9% | 22.0% | 4 |
| k20_middle | 20 | middle | 234 | 18.4% | 41.9% | 17.9% | 21.8% | 5 |
| k20_last | 20 | last | 247 | 14.6% | 45.7% | 19.0% | 20.6% | 5 |

`dlift_rank_median` = median PreFLMR rank (within top-50) of the chosen distractor passage on `distractor_lift` errors. Lower = more semantically similar to the query.

## Notes

- Greedy 7B reader, original question text only, GOLD_IN.
- Distractor-bucket categorization uses case-insensitive ASCII-folded substring match (heuristic; under-counts paraphrases).
- Sensitivity table re-evaluates on the subset where the chosen gold actually appears in PreFLMR top-50 (drops fallback rows). `gold_via_fallback` column in predictions_*.jsonl supports any further re-slicing.
