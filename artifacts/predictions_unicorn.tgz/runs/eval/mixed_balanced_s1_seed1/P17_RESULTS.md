# P17 — Reader Bottleneck Characterization

- pre-reg: METHODOLOGY_NOTE_P17.md (commits 37e3181 + 1a8a08c)
- subset: subset500_v2 (n_full=496, n_kept_primary=495)
  - excluded for short-distractors: 1
  - gold via fallback (`pos_item_ids[0]`): 140 qids
- model: Qwen/Qwen2.5-VL-7B-Instruct
- hardware: NVIDIA RTX 6000 Ada Generation  torch: 2.11.0+cu128  cuDNN SDP: disabled
- wall: 74.6 min  peak VRAM: 19.29 GB
- reader cache: unique=6435 / total_cells=6435 (reuse savings 0.0%)

## Plot

![acc vs k](acc_vs_k.png)

## Primary (full n)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 495 | 62.63% | [58.28, 66.78] | 185 |
| **k3_first** | 3 | first | 0 | 495 | 57.78% | [53.38, 62.05] | 209 |
| **k3_middle** | 3 | middle | 1 | 495 | 58.99% | [54.60, 63.24] | 203 |
| **k3_last** | 3 | last | 2 | 495 | 58.79% | [54.40, 63.04] | 204 |
| **k5_first** | 5 | first | 0 | 495 | 57.58% | [53.18, 61.85] | 210 |
| **k5_middle** | 5 | middle | 2 | 495 | 60.00% | [55.62, 64.22] | 198 |
| **k5_last** | 5 | last | 4 | 495 | 59.19% | [54.81, 63.43] | 202 |
| **k10_first** | 10 | first | 0 | 495 | 55.15% | [50.75, 59.48] | 222 |
| **k10_middle** | 10 | middle | 4 | 495 | 57.37% | [52.98, 61.66] | 211 |
| **k10_last** | 10 | last | 9 | 495 | 55.35% | [50.95, 59.68] | 221 |
| **k20_first** | 20 | first | 0 | 495 | 52.93% | [48.53, 57.29] | 233 |
| **k20_middle** | 20 | middle | 9 | 495 | 53.74% | [49.33, 58.08] | 229 |
| **k20_last** | 20 | last | 19 | 495 | 52.93% | [48.53, 57.29] | 233 |

## Sensitivity (exclude gold-via-fallback rows)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 355 | 66.20% | [61.13, 70.92] | 120 |
| **k3_first** | 3 | first | 0 | 355 | 61.97% | [56.82, 66.87] | 135 |
| **k3_middle** | 3 | middle | 1 | 355 | 63.66% | [58.54, 68.49] | 129 |
| **k3_last** | 3 | last | 2 | 355 | 63.38% | [58.25, 68.22] | 130 |
| **k5_first** | 5 | first | 0 | 355 | 62.25% | [57.11, 67.14] | 134 |
| **k5_middle** | 5 | middle | 2 | 355 | 64.79% | [59.69, 69.57] | 125 |
| **k5_last** | 5 | last | 4 | 355 | 64.51% | [59.40, 69.31] | 126 |
| **k10_first** | 10 | first | 0 | 355 | 59.72% | [54.54, 64.69] | 143 |
| **k10_middle** | 10 | middle | 4 | 355 | 61.97% | [56.82, 66.87] | 135 |
| **k10_last** | 10 | last | 9 | 355 | 60.00% | [54.82, 64.96] | 142 |
| **k20_first** | 20 | first | 0 | 355 | 57.46% | [52.27, 62.50] | 151 |
| **k20_middle** | 20 | middle | 9 | 355 | 58.31% | [53.12, 63.32] | 148 |
| **k20_last** | 20 | last | 19 | 355 | 58.03% | [52.84, 63.05] | 149 |

## Distractor / error analysis (primary)

Per-cell breakdown of error categories, as % of errors in that cell.

| cell | k | position | n_err | extraction_failed | distractor_lift | ambiguous_in_context | hallucinated | dlift_rank_median |
|------|---|----------|------:|------------------:|----------------:|---------------------:|-------------:|------------------:|
| k1 | 1 | - | 185 | 56.2% | 0.0% | 0.0% | 43.8% | - |
| k3_first | 3 | first | 209 | 35.4% | 20.1% | 12.0% | 32.5% | 0 |
| k3_middle | 3 | middle | 203 | 35.5% | 19.2% | 11.8% | 33.5% | 1 |
| k3_last | 3 | last | 204 | 38.2% | 18.1% | 11.3% | 32.4% | 0 |
| k5_first | 5 | first | 210 | 31.4% | 25.2% | 13.8% | 29.5% | 1 |
| k5_middle | 5 | middle | 198 | 33.3% | 23.7% | 13.6% | 29.3% | 1 |
| k5_last | 5 | last | 202 | 34.7% | 24.3% | 13.9% | 27.2% | 1 |
| k10_first | 10 | first | 222 | 21.6% | 32.9% | 16.7% | 28.8% | 3 |
| k10_middle | 10 | middle | 211 | 23.2% | 31.3% | 17.1% | 28.4% | 3 |
| k10_last | 10 | last | 221 | 21.7% | 32.6% | 19.0% | 26.7% | 3 |
| k20_first | 20 | first | 233 | 20.2% | 40.8% | 16.7% | 22.3% | 5 |
| k20_middle | 20 | middle | 229 | 21.0% | 38.9% | 17.9% | 22.3% | 5 |
| k20_last | 20 | last | 233 | 21.5% | 36.9% | 18.5% | 23.2% | 5 |

`dlift_rank_median` = median PreFLMR rank (within top-50) of the chosen distractor passage on `distractor_lift` errors. Lower = more semantically similar to the query.

## Notes

- Greedy 7B reader, original question text only, GOLD_IN.
- Distractor-bucket categorization uses case-insensitive ASCII-folded substring match (heuristic; under-counts paraphrases).
- Sensitivity table re-evaluates on the subset where the chosen gold actually appears in PreFLMR top-50 (drops fallback rows). `gold_via_fallback` column in predictions_*.jsonl supports any further re-slicing.
