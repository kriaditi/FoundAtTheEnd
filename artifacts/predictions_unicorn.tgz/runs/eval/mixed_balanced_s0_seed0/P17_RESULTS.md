# P17 — Reader Bottleneck Characterization

- pre-reg: METHODOLOGY_NOTE_P17.md (commits 37e3181 + 1a8a08c)
- subset: subset500_v2 (n_full=496, n_kept_primary=495)
  - excluded for short-distractors: 1
  - gold via fallback (`pos_item_ids[0]`): 140 qids
- model: Qwen/Qwen2.5-VL-7B-Instruct
- hardware: NVIDIA RTX 6000 Ada Generation  torch: 2.11.0+cu128  cuDNN SDP: disabled
- wall: 77.1 min  peak VRAM: 19.29 GB
- reader cache: unique=6435 / total_cells=6435 (reuse savings 0.0%)

## Plot

![acc vs k](acc_vs_k.png)

## Primary (full n)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 495 | 62.02% | [57.67, 66.19] | 188 |
| **k3_first** | 3 | first | 0 | 495 | 55.96% | [51.56, 60.27] | 218 |
| **k3_middle** | 3 | middle | 1 | 495 | 59.39% | [55.01, 63.63] | 201 |
| **k3_last** | 3 | last | 2 | 495 | 59.80% | [55.42, 64.03] | 199 |
| **k5_first** | 5 | first | 0 | 495 | 54.95% | [50.54, 59.28] | 223 |
| **k5_middle** | 5 | middle | 2 | 495 | 58.59% | [54.20, 62.84] | 205 |
| **k5_last** | 5 | last | 4 | 495 | 58.38% | [53.99, 62.65] | 206 |
| **k10_first** | 10 | first | 0 | 495 | 53.94% | [49.53, 58.28] | 228 |
| **k10_middle** | 10 | middle | 4 | 495 | 55.35% | [50.95, 59.68] | 221 |
| **k10_last** | 10 | last | 9 | 495 | 54.14% | [49.74, 58.48] | 227 |
| **k20_first** | 20 | first | 0 | 495 | 48.89% | [44.51, 53.28] | 253 |
| **k20_middle** | 20 | middle | 9 | 495 | 51.11% | [46.72, 55.49] | 242 |
| **k20_last** | 20 | last | 19 | 495 | 53.74% | [49.33, 58.08] | 229 |

## Sensitivity (exclude gold-via-fallback rows)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 355 | 65.92% | [60.84, 70.65] | 121 |
| **k3_first** | 3 | first | 0 | 355 | 59.44% | [54.25, 64.42] | 144 |
| **k3_middle** | 3 | middle | 1 | 355 | 62.82% | [57.68, 67.68] | 132 |
| **k3_last** | 3 | last | 2 | 355 | 63.38% | [58.25, 68.22] | 130 |
| **k5_first** | 5 | first | 0 | 355 | 58.03% | [52.84, 63.05] | 149 |
| **k5_middle** | 5 | middle | 2 | 355 | 61.69% | [56.53, 66.60] | 136 |
| **k5_last** | 5 | last | 4 | 355 | 61.13% | [55.96, 66.05] | 138 |
| **k10_first** | 10 | first | 0 | 355 | 56.34% | [51.14, 61.40] | 155 |
| **k10_middle** | 10 | middle | 4 | 355 | 58.87% | [53.69, 63.87] | 146 |
| **k10_last** | 10 | last | 9 | 355 | 56.90% | [51.70, 61.95] | 153 |
| **k20_first** | 20 | first | 0 | 355 | 52.68% | [47.48, 57.81] | 168 |
| **k20_middle** | 20 | middle | 9 | 355 | 54.37% | [49.17, 59.47] | 162 |
| **k20_last** | 20 | last | 19 | 355 | 57.75% | [52.55, 62.78] | 150 |

## Distractor / error analysis (primary)

Per-cell breakdown of error categories, as % of errors in that cell.

| cell | k | position | n_err | extraction_failed | distractor_lift | ambiguous_in_context | hallucinated | dlift_rank_median |
|------|---|----------|------:|------------------:|----------------:|---------------------:|-------------:|------------------:|
| k1 | 1 | - | 188 | 50.5% | 0.0% | 0.0% | 49.5% | - |
| k3_first | 3 | first | 218 | 31.2% | 20.6% | 9.6% | 38.5% | 1 |
| k3_middle | 3 | middle | 201 | 35.3% | 16.9% | 9.5% | 38.3% | 0 |
| k3_last | 3 | last | 199 | 39.2% | 17.6% | 9.0% | 34.2% | 1 |
| k5_first | 5 | first | 223 | 29.6% | 29.6% | 10.8% | 30.0% | 1 |
| k5_middle | 5 | middle | 205 | 34.6% | 25.4% | 11.7% | 28.3% | 1 |
| k5_last | 5 | last | 206 | 35.0% | 24.3% | 12.1% | 28.6% | 1 |
| k10_first | 10 | first | 228 | 25.0% | 34.6% | 13.6% | 26.8% | 3 |
| k10_middle | 10 | middle | 221 | 26.7% | 32.6% | 14.5% | 26.2% | 3 |
| k10_last | 10 | last | 227 | 25.6% | 32.6% | 14.5% | 27.3% | 3 |
| k20_first | 20 | first | 253 | 20.2% | 41.9% | 17.0% | 20.9% | 4 |
| k20_middle | 20 | middle | 242 | 22.3% | 36.4% | 16.9% | 24.4% | 4 |
| k20_last | 20 | last | 229 | 20.5% | 34.9% | 20.1% | 24.5% | 5 |

`dlift_rank_median` = median PreFLMR rank (within top-50) of the chosen distractor passage on `distractor_lift` errors. Lower = more semantically similar to the query.

## Notes

- Greedy 7B reader, original question text only, GOLD_IN.
- Distractor-bucket categorization uses case-insensitive ASCII-folded substring match (heuristic; under-counts paraphrases).
- Sensitivity table re-evaluates on the subset where the chosen gold actually appears in PreFLMR top-50 (drops fallback rows). `gold_via_fallback` column in predictions_*.jsonl supports any further re-slicing.
