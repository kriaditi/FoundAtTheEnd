# P17 — Reader Bottleneck Characterization

- pre-reg: METHODOLOGY_NOTE_P17.md (commits 37e3181 + 1a8a08c)
- subset: subset500_v2 (n_full=496, n_kept_primary=495)
  - excluded for short-distractors: 1
  - gold via fallback (`pos_item_ids[0]`): 140 qids
- model: Qwen/Qwen2.5-VL-7B-Instruct
- hardware: NVIDIA RTX 6000 Ada Generation  torch: 2.11.0+cu128  cuDNN SDP: disabled
- wall: 0.1 min  peak VRAM: 0.00 GB
- reader cache: unique=6435 / total_cells=6435 (reuse savings 0.0%)

## Plot

![acc vs k](acc_vs_k.png)

## Primary (full n)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 495 | 69.49% | [65.30, 73.39] | 151 |
| **k3_first** | 3 | first | 0 | 495 | 69.49% | [65.30, 73.39] | 151 |
| **k3_middle** | 3 | middle | 1 | 495 | 13.74% | [10.98, 17.05] | 427 |
| **k3_last** | 3 | last | 2 | 495 | 13.54% | [10.80, 16.83] | 428 |
| **k5_first** | 5 | first | 0 | 495 | 70.30% | [66.13, 74.16] | 147 |
| **k5_middle** | 5 | middle | 2 | 495 | 13.94% | [11.16, 17.27] | 426 |
| **k5_last** | 5 | last | 4 | 495 | 13.94% | [11.16, 17.27] | 426 |
| **k10_first** | 10 | first | 0 | 495 | 69.90% | [65.72, 73.77] | 149 |
| **k10_middle** | 10 | middle | 4 | 495 | 13.74% | [10.98, 17.05] | 427 |
| **k10_last** | 10 | last | 9 | 495 | 13.54% | [10.80, 16.83] | 428 |
| **k20_first** | 20 | first | 0 | 495 | 68.69% | [64.47, 72.62] | 155 |
| **k20_middle** | 20 | middle | 9 | 495 | 14.14% | [11.35, 17.49] | 425 |
| **k20_last** | 20 | last | 19 | 495 | 14.14% | [11.35, 17.49] | 425 |

## Sensitivity (exclude gold-via-fallback rows)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 355 | 73.80% | [68.99, 78.10] | 93 |
| **k3_first** | 3 | first | 0 | 355 | 73.52% | [68.70, 77.84] | 94 |
| **k3_middle** | 3 | middle | 1 | 355 | 16.06% | [12.60, 20.24] | 298 |
| **k3_last** | 3 | last | 2 | 355 | 15.77% | [12.35, 19.93] | 299 |
| **k5_first** | 5 | first | 0 | 355 | 74.37% | [69.58, 78.63] | 91 |
| **k5_middle** | 5 | middle | 2 | 355 | 16.34% | [12.86, 20.54] | 297 |
| **k5_last** | 5 | last | 4 | 355 | 16.06% | [12.60, 20.24] | 298 |
| **k10_first** | 10 | first | 0 | 355 | 73.80% | [68.99, 78.10] | 93 |
| **k10_middle** | 10 | middle | 4 | 355 | 15.77% | [12.35, 19.93] | 299 |
| **k10_last** | 10 | last | 9 | 355 | 15.49% | [12.10, 19.62] | 300 |
| **k20_first** | 20 | first | 0 | 355 | 72.11% | [67.23, 76.52] | 99 |
| **k20_middle** | 20 | middle | 9 | 355 | 15.49% | [12.10, 19.62] | 300 |
| **k20_last** | 20 | last | 19 | 355 | 16.06% | [12.60, 20.24] | 298 |

## Distractor / error analysis (primary)

Per-cell breakdown of error categories, as % of errors in that cell.

| cell | k | position | n_err | extraction_failed | distractor_lift | ambiguous_in_context | hallucinated | dlift_rank_median |
|------|---|----------|------:|------------------:|----------------:|---------------------:|-------------:|------------------:|
| k1 | 1 | - | 151 | 58.3% | 0.0% | 0.0% | 41.7% | - |
| k3_first | 3 | first | 151 | 47.0% | 6.6% | 12.6% | 33.8% | 0 |
| k3_middle | 3 | middle | 427 | 1.4% | 51.5% | 8.0% | 39.1% | 0 |
| k3_last | 3 | last | 428 | 1.4% | 52.6% | 8.2% | 37.9% | 0 |
| k5_first | 5 | first | 147 | 42.9% | 8.2% | 17.0% | 32.0% | 0 |
| k5_middle | 5 | middle | 426 | 2.1% | 54.2% | 8.0% | 35.7% | 0 |
| k5_last | 5 | last | 426 | 2.1% | 54.2% | 8.0% | 35.7% | 0 |
| k10_first | 10 | first | 149 | 37.6% | 8.1% | 24.2% | 30.2% | 0 |
| k10_middle | 10 | middle | 427 | 0.9% | 59.5% | 8.7% | 30.9% | 0 |
| k10_last | 10 | last | 428 | 0.9% | 59.6% | 9.1% | 30.4% | 0 |
| k20_first | 20 | first | 155 | 36.1% | 11.6% | 27.1% | 25.2% | 4 |
| k20_middle | 20 | middle | 425 | 0.5% | 63.1% | 9.4% | 27.1% | 0 |
| k20_last | 20 | last | 425 | 0.5% | 62.6% | 9.4% | 27.5% | 0 |

`dlift_rank_median` = median PreFLMR rank (within top-50) of the chosen distractor passage on `distractor_lift` errors. Lower = more semantically similar to the query.

## Notes

- Greedy 7B reader, original question text only, GOLD_IN.
- Distractor-bucket categorization uses case-insensitive ASCII-folded substring match (heuristic; under-counts paraphrases).
- Sensitivity table re-evaluates on the subset where the chosen gold actually appears in PreFLMR top-50 (drops fallback rows). `gold_via_fallback` column in predictions_*.jsonl supports any further re-slicing.
