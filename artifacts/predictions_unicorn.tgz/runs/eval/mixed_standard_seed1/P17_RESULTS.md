# P17 — Reader Bottleneck Characterization

- pre-reg: METHODOLOGY_NOTE_P17.md (commits 37e3181 + 1a8a08c)
- subset: subset500_v2 (n_full=496, n_kept_primary=495)
  - excluded for short-distractors: 1
  - gold via fallback (`pos_item_ids[0]`): 140 qids
- model: Qwen/Qwen2.5-VL-7B-Instruct
- hardware: NVIDIA RTX 6000 Ada Generation  torch: 2.11.0+cu128  cuDNN SDP: disabled
- wall: 74.8 min  peak VRAM: 19.29 GB
- reader cache: unique=6435 / total_cells=6435 (reuse savings 0.0%)

## Plot

![acc vs k](acc_vs_k.png)

## Primary (full n)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 495 | 62.42% | [58.08, 66.58] | 186 |
| **k3_first** | 3 | first | 0 | 495 | 59.39% | [55.01, 63.63] | 201 |
| **k3_middle** | 3 | middle | 1 | 495 | 60.00% | [55.62, 64.22] | 198 |
| **k3_last** | 3 | last | 2 | 495 | 60.61% | [56.24, 64.81] | 195 |
| **k5_first** | 5 | first | 0 | 495 | 59.39% | [55.01, 63.63] | 201 |
| **k5_middle** | 5 | middle | 2 | 495 | 58.79% | [54.40, 63.04] | 204 |
| **k5_last** | 5 | last | 4 | 495 | 59.39% | [55.01, 63.63] | 201 |
| **k10_first** | 10 | first | 0 | 495 | 55.35% | [50.95, 59.68] | 221 |
| **k10_middle** | 10 | middle | 4 | 495 | 56.77% | [52.37, 61.06] | 214 |
| **k10_last** | 10 | last | 9 | 495 | 56.57% | [52.17, 60.87] | 215 |
| **k20_first** | 20 | first | 0 | 495 | 54.14% | [49.74, 58.48] | 227 |
| **k20_middle** | 20 | middle | 9 | 495 | 54.14% | [49.74, 58.48] | 227 |
| **k20_last** | 20 | last | 19 | 495 | 51.92% | [47.52, 56.29] | 238 |

## Sensitivity (exclude gold-via-fallback rows)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 355 | 66.76% | [61.70, 71.46] | 118 |
| **k3_first** | 3 | first | 0 | 355 | 63.66% | [58.54, 68.49] | 129 |
| **k3_middle** | 3 | middle | 1 | 355 | 64.79% | [59.69, 69.57] | 125 |
| **k3_last** | 3 | last | 2 | 355 | 65.07% | [59.97, 69.84] | 124 |
| **k5_first** | 5 | first | 0 | 355 | 64.51% | [59.40, 69.31] | 126 |
| **k5_middle** | 5 | middle | 2 | 355 | 62.82% | [57.68, 67.68] | 132 |
| **k5_last** | 5 | last | 4 | 355 | 63.66% | [58.54, 68.49] | 129 |
| **k10_first** | 10 | first | 0 | 355 | 59.72% | [54.54, 64.69] | 143 |
| **k10_middle** | 10 | middle | 4 | 355 | 60.85% | [55.68, 65.78] | 139 |
| **k10_last** | 10 | last | 9 | 355 | 60.28% | [55.11, 65.24] | 141 |
| **k20_first** | 20 | first | 0 | 355 | 59.44% | [54.25, 64.42] | 144 |
| **k20_middle** | 20 | middle | 9 | 355 | 58.03% | [52.84, 63.05] | 149 |
| **k20_last** | 20 | last | 19 | 355 | 54.65% | [49.45, 59.75] | 161 |

## Distractor / error analysis (primary)

Per-cell breakdown of error categories, as % of errors in that cell.

| cell | k | position | n_err | extraction_failed | distractor_lift | ambiguous_in_context | hallucinated | dlift_rank_median |
|------|---|----------|------:|------------------:|----------------:|---------------------:|-------------:|------------------:|
| k1 | 1 | - | 186 | 54.8% | 0.0% | 0.0% | 45.2% | - |
| k3_first | 3 | first | 201 | 36.3% | 15.4% | 10.9% | 37.3% | 1 |
| k3_middle | 3 | middle | 198 | 35.9% | 14.6% | 11.1% | 38.4% | 1 |
| k3_last | 3 | last | 195 | 40.5% | 14.4% | 11.3% | 33.8% | 1 |
| k5_first | 5 | first | 201 | 31.8% | 21.9% | 13.4% | 32.8% | 1 |
| k5_middle | 5 | middle | 204 | 33.3% | 24.0% | 14.2% | 28.4% | 2 |
| k5_last | 5 | last | 201 | 34.8% | 21.9% | 13.9% | 29.4% | 1 |
| k10_first | 10 | first | 221 | 22.6% | 31.2% | 18.6% | 27.6% | 3 |
| k10_middle | 10 | middle | 214 | 25.7% | 31.8% | 17.8% | 24.8% | 3 |
| k10_last | 10 | last | 215 | 23.3% | 31.2% | 18.6% | 27.0% | 3 |
| k20_first | 20 | first | 227 | 20.3% | 37.0% | 21.1% | 21.6% | 5 |
| k20_middle | 20 | middle | 227 | 20.3% | 37.4% | 18.5% | 23.8% | 5 |
| k20_last | 20 | last | 238 | 18.1% | 38.7% | 21.8% | 21.4% | 5 |

`dlift_rank_median` = median PreFLMR rank (within top-50) of the chosen distractor passage on `distractor_lift` errors. Lower = more semantically similar to the query.

## Notes

- Greedy 7B reader, original question text only, GOLD_IN.
- Distractor-bucket categorization uses case-insensitive ASCII-folded substring match (heuristic; under-counts paraphrases).
- Sensitivity table re-evaluates on the subset where the chosen gold actually appears in PreFLMR top-50 (drops fallback rows). `gold_via_fallback` column in predictions_*.jsonl supports any further re-slicing.
