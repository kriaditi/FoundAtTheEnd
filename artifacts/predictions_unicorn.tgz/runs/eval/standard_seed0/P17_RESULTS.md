# P17 — Reader Bottleneck Characterization

- pre-reg: METHODOLOGY_NOTE_P17.md (commits 37e3181 + 1a8a08c)
- subset: subset500_v2 (n_full=496, n_kept_primary=495)
  - excluded for short-distractors: 1
  - gold via fallback (`pos_item_ids[0]`): 140 qids
- model: Qwen/Qwen2.5-VL-7B-Instruct
- hardware: NVIDIA RTX 6000 Ada Generation  torch: 2.11.0+cu128  cuDNN SDP: disabled
- wall: 0.1 min  peak VRAM: 0.00 GB
- reader cache: unique=6435 / total_cells=6435 (reuse savings 0.0%)

## Plot

![acc vs k](acc_vs_k.png)

## Primary (full n)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 495 | 62.02% | [57.67, 66.19] | 188 |
| **k3_first** | 3 | first | 0 | 495 | 57.98% | [53.59, 62.25] | 208 |
| **k3_middle** | 3 | middle | 1 | 495 | 60.20% | [55.83, 64.42] | 197 |
| **k3_last** | 3 | last | 2 | 495 | 60.00% | [55.62, 64.22] | 198 |
| **k5_first** | 5 | first | 0 | 495 | 56.57% | [52.17, 60.87] | 215 |
| **k5_middle** | 5 | middle | 2 | 495 | 58.18% | [53.79, 62.45] | 207 |
| **k5_last** | 5 | last | 4 | 495 | 56.57% | [52.17, 60.87] | 215 |
| **k10_first** | 10 | first | 0 | 495 | 54.75% | [50.34, 59.08] | 224 |
| **k10_middle** | 10 | middle | 4 | 495 | 54.55% | [50.14, 58.88] | 225 |
| **k10_last** | 10 | last | 9 | 495 | 53.74% | [49.33, 58.08] | 229 |
| **k20_first** | 20 | first | 0 | 495 | 50.30% | [45.91, 54.69] | 246 |
| **k20_middle** | 20 | middle | 9 | 495 | 49.90% | [45.51, 54.29] | 248 |
| **k20_last** | 20 | last | 19 | 495 | 48.28% | [43.91, 52.68] | 256 |

## Sensitivity (exclude gold-via-fallback rows)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 355 | 67.04% | [61.99, 71.73] | 117 |
| **k3_first** | 3 | first | 0 | 355 | 61.69% | [56.53, 66.60] | 136 |
| **k3_middle** | 3 | middle | 1 | 355 | 64.23% | [59.11, 69.03] | 127 |
| **k3_last** | 3 | last | 2 | 355 | 64.23% | [59.11, 69.03] | 127 |
| **k5_first** | 5 | first | 0 | 355 | 60.85% | [55.68, 65.78] | 139 |
| **k5_middle** | 5 | middle | 2 | 355 | 62.82% | [57.68, 67.68] | 132 |
| **k5_last** | 5 | last | 4 | 355 | 61.69% | [56.53, 66.60] | 136 |
| **k10_first** | 10 | first | 0 | 355 | 59.72% | [54.54, 64.69] | 143 |
| **k10_middle** | 10 | middle | 4 | 355 | 59.44% | [54.25, 64.42] | 144 |
| **k10_last** | 10 | last | 9 | 355 | 58.31% | [53.12, 63.32] | 148 |
| **k20_first** | 20 | first | 0 | 355 | 55.77% | [50.57, 60.85] | 157 |
| **k20_middle** | 20 | middle | 9 | 355 | 54.08% | [48.88, 59.20] | 163 |
| **k20_last** | 20 | last | 19 | 355 | 52.11% | [46.92, 57.26] | 170 |

## Distractor / error analysis (primary)

Per-cell breakdown of error categories, as % of errors in that cell.

| cell | k | position | n_err | extraction_failed | distractor_lift | ambiguous_in_context | hallucinated | dlift_rank_median |
|------|---|----------|------:|------------------:|----------------:|---------------------:|-------------:|------------------:|
| k1 | 1 | - | 188 | 51.1% | 0.0% | 0.0% | 48.9% | - |
| k3_first | 3 | first | 208 | 32.7% | 17.8% | 10.1% | 39.4% | 1 |
| k3_middle | 3 | middle | 197 | 33.0% | 17.8% | 9.1% | 40.1% | 1 |
| k3_last | 3 | last | 198 | 34.8% | 17.2% | 9.6% | 38.4% | 1 |
| k5_first | 5 | first | 215 | 29.3% | 23.7% | 11.2% | 35.8% | 1 |
| k5_middle | 5 | middle | 207 | 30.9% | 21.3% | 10.6% | 37.2% | 1 |
| k5_last | 5 | last | 215 | 29.8% | 21.4% | 10.7% | 38.1% | 1 |
| k10_first | 10 | first | 224 | 22.8% | 32.6% | 15.2% | 29.5% | 2 |
| k10_middle | 10 | middle | 225 | 24.9% | 28.4% | 14.7% | 32.0% | 2 |
| k10_last | 10 | last | 229 | 24.0% | 31.0% | 14.8% | 30.1% | 2 |
| k20_first | 20 | first | 246 | 19.1% | 38.2% | 15.9% | 26.8% | 4 |
| k20_middle | 20 | middle | 248 | 18.1% | 37.1% | 16.9% | 27.8% | 4 |
| k20_last | 20 | last | 256 | 16.8% | 40.6% | 16.8% | 25.8% | 4 |

`dlift_rank_median` = median PreFLMR rank (within top-50) of the chosen distractor passage on `distractor_lift` errors. Lower = more semantically similar to the query.

## Notes

- Greedy 7B reader, original question text only, GOLD_IN.
- Distractor-bucket categorization uses case-insensitive ASCII-folded substring match (heuristic; under-counts paraphrases).
- Sensitivity table re-evaluates on the subset where the chosen gold actually appears in PreFLMR top-50 (drops fallback rows). `gold_via_fallback` column in predictions_*.jsonl supports any further re-slicing.
