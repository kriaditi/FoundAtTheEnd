# P17 — Reader Bottleneck Characterization

- pre-reg: METHODOLOGY_NOTE_P17.md (commits 37e3181 + 1a8a08c)
- subset: subset500_v2 (n_full=496, n_kept_primary=495)
  - excluded for short-distractors: 1
  - gold via fallback (`pos_item_ids[0]`): 140 qids
- model: Qwen/Qwen2.5-VL-7B-Instruct
- hardware: NVIDIA RTX 6000 Ada Generation  torch: 2.11.0+cu128  cuDNN SDP: disabled
- wall: 0.1 min  peak VRAM: 0.00 GB
- reader cache: unique=6435 / total_cells=6435 (reuse savings 0.0%)

## Plot

![acc vs k](acc_vs_k.png)

## Primary (full n)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 495 | 65.66% | [61.37, 69.70] | 170 |
| **k3_first** | 3 | first | 0 | 495 | 62.22% | [57.87, 66.38] | 187 |
| **k3_middle** | 3 | middle | 1 | 495 | 62.83% | [58.49, 66.97] | 184 |
| **k3_last** | 3 | last | 2 | 495 | 63.84% | [59.51, 67.95] | 179 |
| **k5_first** | 5 | first | 0 | 495 | 60.81% | [56.44, 65.01] | 194 |
| **k5_middle** | 5 | middle | 2 | 495 | 62.42% | [58.08, 66.58] | 186 |
| **k5_last** | 5 | last | 4 | 495 | 63.03% | [58.69, 67.17] | 183 |
| **k10_first** | 10 | first | 0 | 495 | 57.17% | [52.77, 61.46] | 212 |
| **k10_middle** | 10 | middle | 4 | 495 | 57.78% | [53.38, 62.05] | 209 |
| **k10_last** | 10 | last | 9 | 495 | 56.77% | [52.37, 61.06] | 214 |
| **k20_first** | 20 | first | 0 | 495 | 52.12% | [47.72, 56.49] | 237 |
| **k20_middle** | 20 | middle | 9 | 495 | 51.11% | [46.72, 55.49] | 242 |
| **k20_last** | 20 | last | 19 | 495 | 51.72% | [47.32, 56.09] | 239 |

## Sensitivity (exclude gold-via-fallback rows)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 355 | 70.99% | [66.06, 75.46] | 103 |
| **k3_first** | 3 | first | 0 | 355 | 66.48% | [61.41, 71.19] | 119 |
| **k3_middle** | 3 | middle | 1 | 355 | 67.89% | [62.86, 72.53] | 114 |
| **k3_last** | 3 | last | 2 | 355 | 69.01% | [64.02, 73.60] | 110 |
| **k5_first** | 5 | first | 0 | 355 | 65.63% | [60.55, 70.38] | 122 |
| **k5_middle** | 5 | middle | 2 | 355 | 67.89% | [62.86, 72.53] | 114 |
| **k5_last** | 5 | last | 4 | 355 | 68.17% | [63.15, 72.80] | 113 |
| **k10_first** | 10 | first | 0 | 355 | 61.69% | [56.53, 66.60] | 136 |
| **k10_middle** | 10 | middle | 4 | 355 | 63.66% | [58.54, 68.49] | 129 |
| **k10_last** | 10 | last | 9 | 355 | 61.69% | [56.53, 66.60] | 136 |
| **k20_first** | 20 | first | 0 | 355 | 56.90% | [51.70, 61.95] | 153 |
| **k20_middle** | 20 | middle | 9 | 355 | 55.21% | [50.01, 60.30] | 159 |
| **k20_last** | 20 | last | 19 | 355 | 54.93% | [49.73, 60.03] | 160 |

## Distractor / error analysis (primary)

Per-cell breakdown of error categories, as % of errors in that cell.

| cell | k | position | n_err | extraction_failed | distractor_lift | ambiguous_in_context | hallucinated | dlift_rank_median |
|------|---|----------|------:|------------------:|----------------:|---------------------:|-------------:|------------------:|
| k1 | 1 | - | 170 | 57.1% | 0.0% | 0.0% | 42.9% | - |
| k3_first | 3 | first | 187 | 38.0% | 19.3% | 10.7% | 32.1% | 1 |
| k3_middle | 3 | middle | 184 | 37.0% | 19.6% | 10.3% | 33.2% | 1 |
| k3_last | 3 | last | 179 | 40.2% | 17.9% | 10.1% | 31.8% | 1 |
| k5_first | 5 | first | 194 | 32.0% | 22.2% | 13.4% | 32.5% | 1 |
| k5_middle | 5 | middle | 186 | 31.7% | 23.7% | 11.8% | 32.8% | 1 |
| k5_last | 5 | last | 183 | 33.3% | 25.1% | 11.5% | 30.1% | 1 |
| k10_first | 10 | first | 212 | 21.2% | 35.8% | 16.5% | 26.4% | 3 |
| k10_middle | 10 | middle | 209 | 21.5% | 35.9% | 16.7% | 25.8% | 3 |
| k10_last | 10 | last | 214 | 22.4% | 31.8% | 17.8% | 28.0% | 3 |
| k20_first | 20 | first | 237 | 15.2% | 44.7% | 15.2% | 24.9% | 5 |
| k20_middle | 20 | middle | 242 | 17.4% | 40.1% | 16.5% | 26.0% | 4 |
| k20_last | 20 | last | 239 | 18.0% | 38.9% | 16.7% | 26.4% | 5 |

`dlift_rank_median` = median PreFLMR rank (within top-50) of the chosen distractor passage on `distractor_lift` errors. Lower = more semantically similar to the query.

## Notes

- Greedy 7B reader, original question text only, GOLD_IN.
- Distractor-bucket categorization uses case-insensitive ASCII-folded substring match (heuristic; under-counts paraphrases).
- Sensitivity table re-evaluates on the subset where the chosen gold actually appears in PreFLMR top-50 (drops fallback rows). `gold_via_fallback` column in predictions_*.jsonl supports any further re-slicing.
