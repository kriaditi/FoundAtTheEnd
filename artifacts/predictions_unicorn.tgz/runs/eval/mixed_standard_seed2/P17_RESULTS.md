# P17 — Reader Bottleneck Characterization

- pre-reg: METHODOLOGY_NOTE_P17.md (commits 37e3181 + 1a8a08c)
- subset: subset500_v2 (n_full=496, n_kept_primary=495)
  - excluded for short-distractors: 1
  - gold via fallback (`pos_item_ids[0]`): 140 qids
- model: Qwen/Qwen2.5-VL-7B-Instruct
- hardware: NVIDIA RTX 6000 Ada Generation  torch: 2.11.0+cu128  cuDNN SDP: disabled
- wall: 77.2 min  peak VRAM: 19.29 GB
- reader cache: unique=6435 / total_cells=6435 (reuse savings 0.0%)

## Plot

![acc vs k](acc_vs_k.png)

## Primary (full n)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 495 | 62.42% | [58.08, 66.58] | 186 |
| **k3_first** | 3 | first | 0 | 495 | 59.19% | [54.81, 63.43] | 202 |
| **k3_middle** | 3 | middle | 1 | 495 | 58.99% | [54.60, 63.24] | 203 |
| **k3_last** | 3 | last | 2 | 495 | 57.98% | [53.59, 62.25] | 208 |
| **k5_first** | 5 | first | 0 | 495 | 57.58% | [53.18, 61.85] | 210 |
| **k5_middle** | 5 | middle | 2 | 495 | 58.79% | [54.40, 63.04] | 204 |
| **k5_last** | 5 | last | 4 | 495 | 56.57% | [52.17, 60.87] | 215 |
| **k10_first** | 10 | first | 0 | 495 | 53.54% | [49.13, 57.89] | 230 |
| **k10_middle** | 10 | middle | 4 | 495 | 54.34% | [49.94, 58.68] | 226 |
| **k10_last** | 10 | last | 9 | 495 | 52.32% | [47.92, 56.69] | 236 |
| **k20_first** | 20 | first | 0 | 495 | 51.31% | [46.92, 55.69] | 241 |
| **k20_middle** | 20 | middle | 9 | 495 | 50.91% | [46.52, 55.29] | 243 |
| **k20_last** | 20 | last | 19 | 495 | 47.88% | [43.51, 52.28] | 258 |

## Sensitivity (exclude gold-via-fallback rows)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 355 | 66.48% | [61.41, 71.19] | 119 |
| **k3_first** | 3 | first | 0 | 355 | 62.54% | [57.39, 67.41] | 133 |
| **k3_middle** | 3 | middle | 1 | 355 | 63.66% | [58.54, 68.49] | 129 |
| **k3_last** | 3 | last | 2 | 355 | 61.97% | [56.82, 66.87] | 135 |
| **k5_first** | 5 | first | 0 | 355 | 61.41% | [56.25, 66.32] | 137 |
| **k5_middle** | 5 | middle | 2 | 355 | 61.97% | [56.82, 66.87] | 135 |
| **k5_last** | 5 | last | 4 | 355 | 60.28% | [55.11, 65.24] | 141 |
| **k10_first** | 10 | first | 0 | 355 | 57.18% | [51.99, 62.23] | 152 |
| **k10_middle** | 10 | middle | 4 | 355 | 58.31% | [53.12, 63.32] | 148 |
| **k10_last** | 10 | last | 9 | 355 | 55.49% | [50.29, 60.58] | 158 |
| **k20_first** | 20 | first | 0 | 355 | 55.77% | [50.57, 60.85] | 157 |
| **k20_middle** | 20 | middle | 9 | 355 | 53.52% | [48.32, 58.64] | 165 |
| **k20_last** | 20 | last | 19 | 355 | 51.27% | [46.08, 56.43] | 173 |

## Distractor / error analysis (primary)

Per-cell breakdown of error categories, as % of errors in that cell.

| cell | k | position | n_err | extraction_failed | distractor_lift | ambiguous_in_context | hallucinated | dlift_rank_median |
|------|---|----------|------:|------------------:|----------------:|---------------------:|-------------:|------------------:|
| k1 | 1 | - | 186 | 51.1% | 0.0% | 0.0% | 48.9% | - |
| k3_first | 3 | first | 202 | 34.2% | 18.3% | 9.4% | 38.1% | 0 |
| k3_middle | 3 | middle | 203 | 38.4% | 15.8% | 10.8% | 35.0% | 1 |
| k3_last | 3 | last | 208 | 38.9% | 17.3% | 9.1% | 34.6% | 0 |
| k5_first | 5 | first | 210 | 31.0% | 25.7% | 11.0% | 32.4% | 1 |
| k5_middle | 5 | middle | 204 | 33.3% | 23.5% | 10.8% | 32.4% | 1 |
| k5_last | 5 | last | 215 | 33.5% | 24.2% | 11.6% | 30.7% | 1 |
| k10_first | 10 | first | 230 | 22.2% | 36.1% | 14.8% | 27.0% | 3 |
| k10_middle | 10 | middle | 226 | 24.8% | 28.8% | 18.6% | 27.9% | 3 |
| k10_last | 10 | last | 236 | 19.9% | 36.0% | 14.4% | 29.7% | 4 |
| k20_first | 20 | first | 241 | 19.5% | 40.7% | 16.2% | 23.7% | 5 |
| k20_middle | 20 | middle | 243 | 17.3% | 42.8% | 17.7% | 22.2% | 5 |
| k20_last | 20 | last | 258 | 14.3% | 44.2% | 17.8% | 23.6% | 5 |

`dlift_rank_median` = median PreFLMR rank (within top-50) of the chosen distractor passage on `distractor_lift` errors. Lower = more semantically similar to the query.

## Notes

- Greedy 7B reader, original question text only, GOLD_IN.
- Distractor-bucket categorization uses case-insensitive ASCII-folded substring match (heuristic; under-counts paraphrases).
- Sensitivity table re-evaluates on the subset where the chosen gold actually appears in PreFLMR top-50 (drops fallback rows). `gold_via_fallback` column in predictions_*.jsonl supports any further re-slicing.
