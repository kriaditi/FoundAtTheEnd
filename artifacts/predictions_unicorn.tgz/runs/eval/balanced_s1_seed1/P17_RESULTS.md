# P17 — Reader Bottleneck Characterization

- pre-reg: METHODOLOGY_NOTE_P17.md (commits 37e3181 + 1a8a08c)
- subset: subset500_v2 (n_full=496, n_kept_primary=495)
  - excluded for short-distractors: 1
  - gold via fallback (`pos_item_ids[0]`): 140 qids
- model: Qwen/Qwen2.5-VL-7B-Instruct
- hardware: NVIDIA RTX 6000 Ada Generation  torch: 2.11.0+cu128  cuDNN SDP: disabled
- wall: 0.1 min  peak VRAM: 0.00 GB
- reader cache: unique=6435 / total_cells=6435 (reuse savings 0.0%)

## Plot

![acc vs k](acc_vs_k.png)

## Primary (full n)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 495 | 65.86% | [61.57, 69.90] | 169 |
| **k3_first** | 3 | first | 0 | 495 | 60.61% | [56.24, 64.81] | 195 |
| **k3_middle** | 3 | middle | 1 | 495 | 58.99% | [54.60, 63.24] | 203 |
| **k3_last** | 3 | last | 2 | 495 | 61.62% | [57.26, 65.80] | 190 |
| **k5_first** | 5 | first | 0 | 495 | 58.18% | [53.79, 62.45] | 207 |
| **k5_middle** | 5 | middle | 2 | 495 | 58.59% | [54.20, 62.84] | 205 |
| **k5_last** | 5 | last | 4 | 495 | 57.98% | [53.59, 62.25] | 208 |
| **k10_first** | 10 | first | 0 | 495 | 53.94% | [49.53, 58.28] | 228 |
| **k10_middle** | 10 | middle | 4 | 495 | 55.35% | [50.95, 59.68] | 221 |
| **k10_last** | 10 | last | 9 | 495 | 53.94% | [49.53, 58.28] | 228 |
| **k20_first** | 20 | first | 0 | 495 | 49.29% | [44.91, 53.69] | 251 |
| **k20_middle** | 20 | middle | 9 | 495 | 52.32% | [47.92, 56.69] | 236 |
| **k20_last** | 20 | last | 19 | 495 | 50.10% | [45.71, 54.49] | 247 |

## Sensitivity (exclude gold-via-fallback rows)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 355 | 71.27% | [66.35, 75.73] | 102 |
| **k3_first** | 3 | first | 0 | 355 | 64.79% | [59.69, 69.57] | 125 |
| **k3_middle** | 3 | middle | 1 | 355 | 63.94% | [58.82, 68.76] | 128 |
| **k3_last** | 3 | last | 2 | 355 | 67.04% | [61.99, 71.73] | 117 |
| **k5_first** | 5 | first | 0 | 355 | 62.82% | [57.68, 67.68] | 132 |
| **k5_middle** | 5 | middle | 2 | 355 | 63.66% | [58.54, 68.49] | 129 |
| **k5_last** | 5 | last | 4 | 355 | 62.82% | [57.68, 67.68] | 132 |
| **k10_first** | 10 | first | 0 | 355 | 58.03% | [52.84, 63.05] | 149 |
| **k10_middle** | 10 | middle | 4 | 355 | 60.28% | [55.11, 65.24] | 141 |
| **k10_last** | 10 | last | 9 | 355 | 60.00% | [54.82, 64.96] | 142 |
| **k20_first** | 20 | first | 0 | 355 | 53.52% | [48.32, 58.64] | 165 |
| **k20_middle** | 20 | middle | 9 | 355 | 57.46% | [52.27, 62.50] | 151 |
| **k20_last** | 20 | last | 19 | 355 | 55.21% | [50.01, 60.30] | 159 |

## Distractor / error analysis (primary)

Per-cell breakdown of error categories, as % of errors in that cell.

| cell | k | position | n_err | extraction_failed | distractor_lift | ambiguous_in_context | hallucinated | dlift_rank_median |
|------|---|----------|------:|------------------:|----------------:|---------------------:|-------------:|------------------:|
| k1 | 1 | - | 169 | 54.4% | 0.0% | 0.0% | 45.6% | - |
| k3_first | 3 | first | 195 | 33.8% | 21.5% | 8.7% | 35.9% | 0 |
| k3_middle | 3 | middle | 203 | 34.5% | 20.2% | 8.9% | 36.5% | 1 |
| k3_last | 3 | last | 190 | 38.9% | 19.5% | 6.8% | 34.7% | 1 |
| k5_first | 5 | first | 207 | 30.0% | 25.6% | 9.7% | 34.8% | 1 |
| k5_middle | 5 | middle | 205 | 31.2% | 24.4% | 10.7% | 33.7% | 1 |
| k5_last | 5 | last | 208 | 30.8% | 25.0% | 11.1% | 33.2% | 1 |
| k10_first | 10 | first | 228 | 19.3% | 37.7% | 14.9% | 28.1% | 4 |
| k10_middle | 10 | middle | 221 | 22.6% | 33.5% | 14.5% | 29.4% | 4 |
| k10_last | 10 | last | 228 | 21.9% | 33.8% | 14.0% | 30.3% | 4 |
| k20_first | 20 | first | 251 | 15.5% | 47.0% | 13.5% | 23.9% | 5 |
| k20_middle | 20 | middle | 236 | 18.2% | 43.6% | 14.0% | 24.2% | 4 |
| k20_last | 20 | last | 247 | 17.0% | 45.3% | 15.0% | 22.7% | 5 |

`dlift_rank_median` = median PreFLMR rank (within top-50) of the chosen distractor passage on `distractor_lift` errors. Lower = more semantically similar to the query.

## Notes

- Greedy 7B reader, original question text only, GOLD_IN.
- Distractor-bucket categorization uses case-insensitive ASCII-folded substring match (heuristic; under-counts paraphrases).
- Sensitivity table re-evaluates on the subset where the chosen gold actually appears in PreFLMR top-50 (drops fallback rows). `gold_via_fallback` column in predictions_*.jsonl supports any further re-slicing.
