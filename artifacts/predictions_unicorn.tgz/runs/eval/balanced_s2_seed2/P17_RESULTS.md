# P17 — Reader Bottleneck Characterization

- pre-reg: METHODOLOGY_NOTE_P17.md (commits 37e3181 + 1a8a08c)
- subset: subset500_v2 (n_full=496, n_kept_primary=495)
  - excluded for short-distractors: 1
  - gold via fallback (`pos_item_ids[0]`): 140 qids
- model: Qwen/Qwen2.5-VL-7B-Instruct
- hardware: NVIDIA RTX 6000 Ada Generation  torch: 2.11.0+cu128  cuDNN SDP: disabled
- wall: 0.1 min  peak VRAM: 0.00 GB
- reader cache: unique=6435 / total_cells=6435 (reuse savings 0.0%)

## Plot

![acc vs k](acc_vs_k.png)

## Primary (full n)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 495 | 65.86% | [61.57, 69.90] | 169 |
| **k3_first** | 3 | first | 0 | 495 | 59.39% | [55.01, 63.63] | 201 |
| **k3_middle** | 3 | middle | 1 | 495 | 60.20% | [55.83, 64.42] | 197 |
| **k3_last** | 3 | last | 2 | 495 | 62.42% | [58.08, 66.58] | 186 |
| **k5_first** | 5 | first | 0 | 495 | 59.60% | [55.22, 63.83] | 200 |
| **k5_middle** | 5 | middle | 2 | 495 | 61.01% | [56.64, 65.21] | 193 |
| **k5_last** | 5 | last | 4 | 495 | 60.00% | [55.62, 64.22] | 198 |
| **k10_first** | 10 | first | 0 | 495 | 56.16% | [51.76, 60.47] | 217 |
| **k10_middle** | 10 | middle | 4 | 495 | 56.77% | [52.37, 61.06] | 214 |
| **k10_last** | 10 | last | 9 | 495 | 56.36% | [51.96, 60.67] | 216 |
| **k20_first** | 20 | first | 0 | 495 | 52.53% | [48.12, 56.89] | 235 |
| **k20_middle** | 20 | middle | 9 | 495 | 51.11% | [46.72, 55.49] | 242 |
| **k20_last** | 20 | last | 19 | 495 | 52.32% | [47.92, 56.69] | 236 |

## Sensitivity (exclude gold-via-fallback rows)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 355 | 69.86% | [64.89, 74.40] | 107 |
| **k3_first** | 3 | first | 0 | 355 | 62.25% | [57.11, 67.14] | 134 |
| **k3_middle** | 3 | middle | 1 | 355 | 63.94% | [58.82, 68.76] | 128 |
| **k3_last** | 3 | last | 2 | 355 | 66.20% | [61.13, 70.92] | 120 |
| **k5_first** | 5 | first | 0 | 355 | 63.94% | [58.82, 68.76] | 128 |
| **k5_middle** | 5 | middle | 2 | 355 | 65.35% | [60.26, 70.11] | 123 |
| **k5_last** | 5 | last | 4 | 355 | 64.23% | [59.11, 69.03] | 127 |
| **k10_first** | 10 | first | 0 | 355 | 60.28% | [55.11, 65.24] | 141 |
| **k10_middle** | 10 | middle | 4 | 355 | 59.72% | [54.54, 64.69] | 143 |
| **k10_last** | 10 | last | 9 | 355 | 59.44% | [54.25, 64.42] | 144 |
| **k20_first** | 20 | first | 0 | 355 | 57.46% | [52.27, 62.50] | 151 |
| **k20_middle** | 20 | middle | 9 | 355 | 54.08% | [48.88, 59.20] | 163 |
| **k20_last** | 20 | last | 19 | 355 | 56.34% | [51.14, 61.40] | 155 |

## Distractor / error analysis (primary)

Per-cell breakdown of error categories, as % of errors in that cell.

| cell | k | position | n_err | extraction_failed | distractor_lift | ambiguous_in_context | hallucinated | dlift_rank_median |
|------|---|----------|------:|------------------:|----------------:|---------------------:|-------------:|------------------:|
| k1 | 1 | - | 169 | 56.2% | 0.0% | 0.0% | 43.8% | - |
| k3_first | 3 | first | 201 | 33.3% | 18.9% | 10.4% | 37.3% | 0 |
| k3_middle | 3 | middle | 197 | 35.5% | 15.7% | 10.7% | 38.1% | 1 |
| k3_last | 3 | last | 186 | 35.5% | 14.5% | 11.8% | 38.2% | 1 |
| k5_first | 5 | first | 200 | 30.5% | 25.5% | 12.5% | 31.5% | 2 |
| k5_middle | 5 | middle | 193 | 30.6% | 24.4% | 11.9% | 33.2% | 1 |
| k5_last | 5 | last | 198 | 32.8% | 24.7% | 11.6% | 30.8% | 1 |
| k10_first | 10 | first | 217 | 23.0% | 35.9% | 14.3% | 26.7% | 3 |
| k10_middle | 10 | middle | 214 | 23.8% | 32.2% | 15.0% | 29.0% | 3 |
| k10_last | 10 | last | 216 | 22.2% | 34.7% | 14.4% | 28.7% | 3 |
| k20_first | 20 | first | 235 | 18.7% | 40.0% | 17.0% | 24.3% | 5 |
| k20_middle | 20 | middle | 242 | 16.9% | 39.7% | 17.8% | 25.6% | 5 |
| k20_last | 20 | last | 236 | 17.4% | 41.1% | 17.4% | 24.2% | 4 |

`dlift_rank_median` = median PreFLMR rank (within top-50) of the chosen distractor passage on `distractor_lift` errors. Lower = more semantically similar to the query.

## Notes

- Greedy 7B reader, original question text only, GOLD_IN.
- Distractor-bucket categorization uses case-insensitive ASCII-folded substring match (heuristic; under-counts paraphrases).
- Sensitivity table re-evaluates on the subset where the chosen gold actually appears in PreFLMR top-50 (drops fallback rows). `gold_via_fallback` column in predictions_*.jsonl supports any further re-slicing.
