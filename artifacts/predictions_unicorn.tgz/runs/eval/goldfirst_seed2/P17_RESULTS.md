# P17 — Reader Bottleneck Characterization

- pre-reg: METHODOLOGY_NOTE_P17.md (commits 37e3181 + 1a8a08c)
- subset: subset500_v2 (n_full=496, n_kept_primary=495)
  - excluded for short-distractors: 1
  - gold via fallback (`pos_item_ids[0]`): 140 qids
- model: Qwen/Qwen2.5-VL-7B-Instruct
- hardware: NVIDIA RTX 6000 Ada Generation  torch: 2.11.0+cu128  cuDNN SDP: disabled
- wall: 0.1 min  peak VRAM: 0.00 GB
- reader cache: unique=6435 / total_cells=6435 (reuse savings 0.0%)

## Plot

![acc vs k](acc_vs_k.png)

## Primary (full n)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 495 | 69.09% | [64.89, 73.00] | 153 |
| **k3_first** | 3 | first | 0 | 495 | 69.70% | [65.51, 73.58] | 150 |
| **k3_middle** | 3 | middle | 1 | 495 | 14.75% | [11.90, 18.14] | 422 |
| **k3_last** | 3 | last | 2 | 495 | 14.55% | [11.71, 17.92] | 423 |
| **k5_first** | 5 | first | 0 | 495 | 69.29% | [65.09, 73.20] | 152 |
| **k5_middle** | 5 | middle | 2 | 495 | 14.14% | [11.35, 17.49] | 425 |
| **k5_last** | 5 | last | 4 | 495 | 13.74% | [10.98, 17.05] | 427 |
| **k10_first** | 10 | first | 0 | 495 | 69.70% | [65.51, 73.58] | 150 |
| **k10_middle** | 10 | middle | 4 | 495 | 13.74% | [10.98, 17.05] | 427 |
| **k10_last** | 10 | last | 9 | 495 | 13.94% | [11.16, 17.27] | 426 |
| **k20_first** | 20 | first | 0 | 495 | 68.89% | [64.68, 72.81] | 154 |
| **k20_middle** | 20 | middle | 9 | 495 | 13.94% | [11.16, 17.27] | 426 |
| **k20_last** | 20 | last | 19 | 495 | 13.94% | [11.16, 17.27] | 426 |

## Sensitivity (exclude gold-via-fallback rows)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 355 | 73.24% | [68.40, 77.58] | 95 |
| **k3_first** | 3 | first | 0 | 355 | 73.80% | [68.99, 78.10] | 93 |
| **k3_middle** | 3 | middle | 1 | 355 | 17.46% | [13.87, 21.76] | 293 |
| **k3_last** | 3 | last | 2 | 355 | 17.75% | [14.12, 22.06] | 292 |
| **k5_first** | 5 | first | 0 | 355 | 73.80% | [68.99, 78.10] | 93 |
| **k5_middle** | 5 | middle | 2 | 355 | 17.18% | [13.62, 21.45] | 294 |
| **k5_last** | 5 | last | 4 | 355 | 16.62% | [13.11, 20.85] | 296 |
| **k10_first** | 10 | first | 0 | 355 | 74.37% | [69.58, 78.63] | 91 |
| **k10_middle** | 10 | middle | 4 | 355 | 16.62% | [13.11, 20.85] | 296 |
| **k10_last** | 10 | last | 9 | 355 | 16.90% | [13.36, 21.15] | 295 |
| **k20_first** | 20 | first | 0 | 355 | 74.93% | [70.17, 79.16] | 89 |
| **k20_middle** | 20 | middle | 9 | 355 | 16.34% | [12.86, 20.54] | 297 |
| **k20_last** | 20 | last | 19 | 355 | 16.34% | [12.86, 20.54] | 297 |

## Distractor / error analysis (primary)

Per-cell breakdown of error categories, as % of errors in that cell.

| cell | k | position | n_err | extraction_failed | distractor_lift | ambiguous_in_context | hallucinated | dlift_rank_median |
|------|---|----------|------:|------------------:|----------------:|---------------------:|-------------:|------------------:|
| k1 | 1 | - | 153 | 64.7% | 0.0% | 0.0% | 35.3% | - |
| k3_first | 3 | first | 150 | 48.0% | 3.3% | 16.7% | 32.0% | 0 |
| k3_middle | 3 | middle | 422 | 1.2% | 53.8% | 7.3% | 37.7% | 0 |
| k3_last | 3 | last | 423 | 0.7% | 53.2% | 7.8% | 38.3% | 0 |
| k5_first | 5 | first | 152 | 45.4% | 6.6% | 19.7% | 28.3% | 2 |
| k5_middle | 5 | middle | 425 | 1.2% | 55.3% | 8.2% | 35.3% | 0 |
| k5_last | 5 | last | 427 | 0.9% | 54.6% | 8.4% | 36.1% | 0 |
| k10_first | 10 | first | 150 | 35.3% | 5.3% | 30.0% | 29.3% | 2 |
| k10_middle | 10 | middle | 427 | 0.2% | 58.8% | 8.4% | 32.6% | 0 |
| k10_last | 10 | last | 426 | 0.2% | 59.9% | 8.7% | 31.2% | 0 |
| k20_first | 20 | first | 154 | 30.5% | 7.8% | 31.8% | 29.9% | 4 |
| k20_middle | 20 | middle | 426 | 0.7% | 64.3% | 7.7% | 27.2% | 0 |
| k20_last | 20 | last | 426 | 0.5% | 64.6% | 7.7% | 27.2% | 0 |

`dlift_rank_median` = median PreFLMR rank (within top-50) of the chosen distractor passage on `distractor_lift` errors. Lower = more semantically similar to the query.

## Notes

- Greedy 7B reader, original question text only, GOLD_IN.
- Distractor-bucket categorization uses case-insensitive ASCII-folded substring match (heuristic; under-counts paraphrases).
- Sensitivity table re-evaluates on the subset where the chosen gold actually appears in PreFLMR top-50 (drops fallback rows). `gold_via_fallback` column in predictions_*.jsonl supports any further re-slicing.
