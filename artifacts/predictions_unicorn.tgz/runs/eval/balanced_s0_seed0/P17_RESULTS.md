# P17 — Reader Bottleneck Characterization

- pre-reg: METHODOLOGY_NOTE_P17.md (commits 37e3181 + 1a8a08c)
- subset: subset500_v2 (n_full=496, n_kept_primary=495)
  - excluded for short-distractors: 1
  - gold via fallback (`pos_item_ids[0]`): 140 qids
- model: Qwen/Qwen2.5-VL-7B-Instruct
- hardware: NVIDIA RTX 6000 Ada Generation  torch: 2.11.0+cu128  cuDNN SDP: disabled
- wall: 0.1 min  peak VRAM: 0.00 GB
- reader cache: unique=6435 / total_cells=6435 (reuse savings 0.0%)

## Plot

![acc vs k](acc_vs_k.png)

## Primary (full n)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 495 | 64.24% | [59.93, 68.34] | 177 |
| **k3_first** | 3 | first | 0 | 495 | 56.57% | [52.17, 60.87] | 215 |
| **k3_middle** | 3 | middle | 1 | 495 | 58.38% | [53.99, 62.65] | 206 |
| **k3_last** | 3 | last | 2 | 495 | 60.00% | [55.62, 64.22] | 198 |
| **k5_first** | 5 | first | 0 | 495 | 55.35% | [50.95, 59.68] | 221 |
| **k5_middle** | 5 | middle | 2 | 495 | 58.59% | [54.20, 62.84] | 205 |
| **k5_last** | 5 | last | 4 | 495 | 57.98% | [53.59, 62.25] | 208 |
| **k10_first** | 10 | first | 0 | 495 | 52.12% | [47.72, 56.49] | 237 |
| **k10_middle** | 10 | middle | 4 | 495 | 55.96% | [51.56, 60.27] | 218 |
| **k10_last** | 10 | last | 9 | 495 | 53.54% | [49.13, 57.89] | 230 |
| **k20_first** | 20 | first | 0 | 495 | 49.90% | [45.51, 54.29] | 248 |
| **k20_middle** | 20 | middle | 9 | 495 | 50.30% | [45.91, 54.69] | 246 |
| **k20_last** | 20 | last | 19 | 495 | 48.89% | [44.51, 53.28] | 253 |

## Sensitivity (exclude gold-via-fallback rows)

### 

| cell | k | position | gold_idx | n | acc_full | wilson 95% CI | n_err |
|------|---|----------|---------:|--:|---------:|---------------|------:|
| **k1** | 1 | - | 0 | 355 | 70.70% | [65.77, 75.20] | 104 |
| **k3_first** | 3 | first | 0 | 355 | 61.41% | [56.25, 66.32] | 137 |
| **k3_middle** | 3 | middle | 1 | 355 | 63.38% | [58.25, 68.22] | 130 |
| **k3_last** | 3 | last | 2 | 355 | 65.07% | [59.97, 69.84] | 124 |
| **k5_first** | 5 | first | 0 | 355 | 59.72% | [54.54, 64.69] | 143 |
| **k5_middle** | 5 | middle | 2 | 355 | 63.66% | [58.54, 68.49] | 129 |
| **k5_last** | 5 | last | 4 | 355 | 63.10% | [57.96, 67.95] | 131 |
| **k10_first** | 10 | first | 0 | 355 | 56.34% | [51.14, 61.40] | 155 |
| **k10_middle** | 10 | middle | 4 | 355 | 60.56% | [55.39, 65.51] | 140 |
| **k10_last** | 10 | last | 9 | 355 | 58.31% | [53.12, 63.32] | 148 |
| **k20_first** | 20 | first | 0 | 355 | 54.37% | [49.17, 59.47] | 162 |
| **k20_middle** | 20 | middle | 9 | 355 | 54.93% | [49.73, 60.03] | 160 |
| **k20_last** | 20 | last | 19 | 355 | 53.80% | [48.60, 58.92] | 164 |

## Distractor / error analysis (primary)

Per-cell breakdown of error categories, as % of errors in that cell.

| cell | k | position | n_err | extraction_failed | distractor_lift | ambiguous_in_context | hallucinated | dlift_rank_median |
|------|---|----------|------:|------------------:|----------------:|---------------------:|-------------:|------------------:|
| k1 | 1 | - | 177 | 49.2% | 0.0% | 0.0% | 50.8% | - |
| k3_first | 3 | first | 215 | 33.0% | 16.7% | 10.2% | 40.0% | 0 |
| k3_middle | 3 | middle | 206 | 31.6% | 18.4% | 9.2% | 40.8% | 0 |
| k3_last | 3 | last | 198 | 32.3% | 16.7% | 9.1% | 41.9% | 0 |
| k5_first | 5 | first | 221 | 29.9% | 24.0% | 10.0% | 36.2% | 1 |
| k5_middle | 5 | middle | 205 | 27.8% | 24.4% | 10.2% | 37.6% | 1 |
| k5_last | 5 | last | 208 | 28.8% | 21.6% | 9.6% | 39.9% | 1 |
| k10_first | 10 | first | 237 | 21.9% | 34.6% | 15.2% | 28.3% | 2 |
| k10_middle | 10 | middle | 218 | 22.5% | 30.3% | 13.3% | 33.9% | 2 |
| k10_last | 10 | last | 230 | 20.9% | 33.5% | 13.5% | 32.2% | 2 |
| k20_first | 20 | first | 248 | 17.3% | 37.9% | 17.3% | 27.4% | 4 |
| k20_middle | 20 | middle | 246 | 15.0% | 37.0% | 17.1% | 30.9% | 4 |
| k20_last | 20 | last | 253 | 16.6% | 41.1% | 15.4% | 26.9% | 4 |

`dlift_rank_median` = median PreFLMR rank (within top-50) of the chosen distractor passage on `distractor_lift` errors. Lower = more semantically similar to the query.

## Notes

- Greedy 7B reader, original question text only, GOLD_IN.
- Distractor-bucket categorization uses case-insensitive ASCII-folded substring match (heuristic; under-counts paraphrases).
- Sensitivity table re-evaluates on the subset where the chosen gold actually appears in PreFLMR top-50 (drops fallback rows). `gold_via_fallback` column in predictions_*.jsonl supports any further re-slicing.
